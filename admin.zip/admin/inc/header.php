<?php
	require_once("init.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || 
{widgetcode:"8db24bb8705830c385dfd0082c698147268d9b271d73515c11d97523ab2381c7", values:{},ready:function(){}};
var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;
s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);d.write("<div id='zsiqwidget'></div>");
</script>
  <link rel="shortcut icon" href="../images/Genie.png" />
  <title>Make A Wish</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="./../css/bootstrap.min.css">
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
 <link rel="stylesheet" type="text/css" href="../css/hackerkernel.css">
  <link rel="stylesheet" type="text/css" href="../css/cart.css">
</head>
<body>