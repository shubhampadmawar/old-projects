<?php
  require_once("inc/header.php");
  require_once("inc/navbar.php");
  require_once("../classes/Upload.php");
  // if admin is not login send him to login.php
  not_login($_SESSION['admin_id'], "login.php");

  //check that the order type is in the $_GET
  $allowed_type = array("1","2","3","4","5","6");
  if (isset($_GET['status']) && in_array($_GET['status'], $allowed_type)) {
    $status_no = escape($_GET['status']);
    // set the status_name
    switch ($status_no) {
      case '1':
        $status_name = "Processing";
        break;
      case "2":
        $status_name = "Processed";
        break;
      case "3":
        $status_name = "Shipped";
        break;
      case "4":
        $status_name = "Deliverd";
        break;
      case "5":
        $status_name = "Canceled";
        break;
      case '6':
        $status_name = "Returned";
        break;
    }
  }else{
    echo "<h1 class='text-center text-bs-primary text-upper'>Invalid Url</h1>";
    exit();
  }
?>
<div class="container padding-10">
  <div id="search-container">
  <center>
  <div class="btn-group">
    <a href="order.php?status=1" class="btn btn-primary">Processing Orders</a>
    <a href="order.php?status=2" class="btn btn-primary">Processed Orders</a>
    <a href="order.php?status=3" class="btn btn-primary">Shipped Orders</a>
    <a href="order.php?status=4" class="btn btn-primary">Deliverd Orders</a>
    <a href="order.php?status=5" class="btn btn-primary">Canceled Orders</a>
    <a href="order.php?status=6" class="btn btn-primary">Returned Orders</a>
  </div>
  </center>
    <h1 class="text-center text-bs-primary text-upper"><?php echo $status_name ?> orders</h1>
    <?php
      // fetch all the new orders
        $orders = $db->FetchAll("*","buy","status_code='$status_no'","id='ASC'");
        // show if their is no orders
        if (empty($orders)) {
          echo "<h3 class='text-center text-upper'>No Orders</h3>";
          exit();
        }
        // show if their is orders
        foreach ($orders as $key => $order) {
          echo "<div class='order-container'><div class='table-responsive'>"; //product order container
          echo "<table class='table table-condensed'>"; //table
          echo "
              <th>Order Id</th>
              <th>User Id</th>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Address</th>
              <th>Customer Wish</th>
              <th>Booked Time</th>
              <th>Dispatch Time</th><tr>";

          $address = $order['address']. " ".$order['city']. " ".$order['pincode'];
          $booked_time = time_ago($order['booked_time']);
          // if item is dispatch show dispatch time else show not yet
          if ($order['dispatch_time'] != 0) {
            $dispatch_time = time_ago($order['dispatch_time']);
          }else{
            $dispatch_time = "Not Yet";
          }

          echo "<td>{$order['id']}</td>
                <td>{$order['user_id']}</td>
                <td>{$order['name']}</td>
                <td>{$order['email']}</td>
                <td>{$order['mobile']}</td>
                <td>{$address}</td>
                <td>{$order['wish']}</td>
                <td>{$booked_time}</td>
                <td>{$dispatch_time}</td>
          ";



          echo "</table>";
          /*fetch the product stack and remove the */
          $product_stack = $order['product_stack'];
          $explode = explode(",", $product_stack);
          // $key = count($explode) - 1;
          // unset($explode[$key]);
          // fetch the product with the product id
          echo "<table class='table'>
                <th>Menu Id</th>
                <th>Menu Name</th>
                <th>Shipping charges</th>
                <th>Subtotal</th>
                <th>Total</th>
                <tr>
          ";
          $grand_total = 0;
          foreach ($explode as $key => $product_id) {
           
            if (strlen($product_id)>3) {

                $p_id= (float)$product_id;
                //For Mini Paatha
              if ($p_id>78 && $p_id<79) {
                # code...
                 $product = $db->Fetch("id,name,sp,shipping","product","id='78'");
                 $total = $product['shipping'] + $product['sp'];
                  
           
            $b=(int)substr($product_id,3,1);
            $c=(int)substr($product_id,4,1);
            $d=(int)substr($product_id,5,1);
            $e=(int)substr($product_id,6,1);
            
            //Raita
            switch ($e) {
                case 1:
                    $raita="Boondi Raita";
                    break;
                case 2:
                    $raita="Mix";
                    break;
                case 3:
                    $raita="Plain Curd";
                    break;
                default:
                   $raita="Plain Curd";
                }
            //Sabji
            switch ($d) {
                case 1:
                    $sabji=" Chole ";
                    break;
                case 2:
                    $sabji=" Rajma ";
                    break;
                case 3:
                    $sabji=" Dal Makhani ";
                    break;
                case 4:
                    $sabji=" Dal Fry ";
                    break;
                default:
                   $sabji=" Chole ";
                }
             //Roll 1
            switch ($c) {
                case 1:
                    $roll1=" Aloo Paratha ";
                    break;
                case 2:
                    $roll1=" Gobi Paratha ";
                    break;
                case 3:
                    $roll1=" Peas Paratha ";
                    break;
                case 4:
                    $roll1=" Onion Paratha";
                    break;
                default:
                   $roll1=" Aloo Paratha ";
                }
            //Roll 1
            switch ($b) {
                case 1:
                    $roll2=" Aloo Paratha ";
                    break;
                case 2:
                    $roll2=" Gobi Paratha ";
                    break;
                case 3:
                    $roll2=" Peas Paratha ";
                    break;
                case 4:
                    $roll2=" Onion Paratha";
                    break;
                default:
                   $roll2=" Aloo Paratha ";
                }



                echo "
                <td>{$product['id']}</td>
                <td>{$product['name']}
                      <br><h5>First Paratha - $roll1</h5>
                      <br><h5>Second Paratha - $roll2</h5>
                      <br><h5>Raita - $raita</h5>
                      <br><h5>Sabji - $sabji</h5>


                </td>
                <td>{$product['shipping']}</td>
                <td>{$product['sp']}</td>
                <td>{$total}</td><tr>";
                $grand_total += $total;
                // calculate grand total
              }
              //For Paratha Combo
              if ($p_id>79 && $p_id<80) {
                # code...
                 $product = $db->Fetch("id,name,sp,shipping","product","id='79'");
                 $total = $product['shipping'] + $product['sp'];
               
            $b=(int)substr($product_id,3,1);
            $c=(int)substr($product_id,4,1);
            $d=(int)substr($product_id,5,1);
            //Raita
            switch ($d) {
                case 1:
                    $raita="Boondi Raita";
                    break;
                case 2:
                    $raita="Mix";
                    break;
                case 3:
                    $raita="Plain Curd";
                    break;
                default:
                   $raita="Plain Curd";
                }
            
             //Roll 2
            switch ($c) {
                case 1:
                    $roll2=" Cheese Onion Paratha ";
                    break;
                case 2:
                    $roll2=" Paneer Onion Paratha ";
                    break;
                case 3:
                    $roll2=" Methi Corn Paratha ";
                    break;
                case 4:
                    $roll2=" Gobi Chilli Cheese Paratha ";
                    break;
                case 5:
                    $roll2=" Peas Paneer Paratha ";
                    break;
                case 6:
                    $roll2="Mix Paratha";
                    break;
                default:
                   $roll2=" Cheese Onion Paratha ";
                }

            //Roll 1
            switch ($b) {
                case 1:
                    $roll1=" Cheese Onion Paratha ";
                    break;
                case 2:
                    $roll1=" Paneer Onion Paratha ";
                    break;
                case 3:
                    $roll1=" Methi Corn Paratha ";
                    break;
                case 4:
                    $roll1=" Gobi Chilli Cheese Paratha ";
                    break;
                case 5:
                    $roll1=" Peas Paneer Paratha";
                    break;
                case 6:
                    $roll1="Mix Paratha";
                    break;
                default:
                   $roll1=" Cheese Onion Paratha ";
                }



                echo "
                <td>{$product['id']}</td>
                <td>{$product['name']}
                      <br><h5>1st Paratha - $roll1</h5>
                      <br><h5>2nd Paratha - $roll2</h5>
                      <br><h5>Raita - $raita</h5>


                </td>
                <td>{$product['shipping']}</td>
                <td>{$product['sp']}</td>
                <td>{$total}</td><tr>";
                $grand_total += $total;
                // calculate grand total
              }

              //Specail Paratha Combo
              if ($p_id>80 && $p_id<81) {
                # code...
                 $product = $db->Fetch("id,name,sp,shipping","product","id='80'");
                 $total = $product['shipping'] + $product['sp'];
                 
            
            $b=(int)substr($product_id,3,1);
            $c=(int)substr($product_id,4,1);
            $d=(int)substr($product_id,5,1);
            $e=(int)substr($product_id,6,1);
            //Raita1
            switch ($e) {
                case 1:
                    $raita2="Boondi Raita";
                    break;
                case 2:
                    $raita2="Mix";
                    break;
                case 3:
                    $raita2="Plain Curd";
                    break;
                default:
                   $raita2="Plain Curd";
                }
            //echo "Raita 2= '$raita2' = '$b'  '$a'";
            //Raita2
            switch ($d) {
                case 1:
                    $raita1="Boondi Raita";
                    break;
                case 2:
                    $raita1="Mix";
                    break;
                case 3:
                    $raita1="Plain Curd";
                    break;
                default:
                   $raita1="Plain Curd";
                }
            //Sabji
            switch ($c) {
                case 1:
                    $sabji=" Chole ";
                    break;
                case 2:
                    $sabji=" Rajma ";
                    break;
                case 3:
                    $sabji=" Dal Makhani ";
                    break;
                case 4:
                    $sabji=" Dal ";
                    break;
                case 5:
                    $sabji=" Kadi ";
                    break;
                default:
                   $sabji=" Chole ";
                }
             //Roll 1
            switch ($b) {
                case 1:
                    $roll1=" Aloo Paratha ";
                    break;
                case 2:
                    $roll1=" Methi Paratha ";
                    break;
                case 3:
                    $roll1=" Gobi Peas Paratha ";
                    break;
                case 4:
                    $roll1=" Aloo Methi Paratha ";
                    break;
                case 5:
                    $roll1=" Aloo Peas Paratha ";
                    break;
                default:
                   $roll1=" Aloo Paratha ";
                }
                echo "
                <td>{$product['id']}</td>
                <td>{$product['name']}
                      <br><h5>Paratha - $roll1</h5>
                      <br><h5>Sabji - $sabji</h5>
                      <br><h5>1st Raita - $raita1</h5>
                      <br><h5>2nd Raita - $raita2</h5>

                </td>
                <td>{$product['shipping']}</td>
                <td>{$product['sp']}</td>
                <td>{$total}</td><tr>";
                $grand_total += $total;
                // calculate grand total
              }
            }
            else{

                 $product = $db->Fetch("id,name,sp,shipping","product","id='$product_id'");
                 $total = $product['shipping'] + $product['sp'];
                  echo "
                  <td>{$product['id']}</td>
                  <td>{$product['name']}</td>
                  <td>{$product['shipping']}</td>
                  <td>{$product['sp']}</td>
                  <td>{$total}</td><tr>";
                  // calculate grand total
                  $grand_total += $total;
              }
          }
          echo "<td><a href='change_order_status.php?id={$order['id']}'>Change Status</a></td><td></td><td></td><td><strong>Grand Total</strong></td><td>{$grand_total}</td>"; //grand total
          echo "</table>
          </div></div>"; //close poduct order container
        }
    ?>
  </div>
  <?php require_once("../inc/footer-nav.php"); ?>
</div>
<?php require_once("inc/footer.php"); ?>
