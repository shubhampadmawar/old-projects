<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");
	require_once("../classes/Upload.php");
	// if admin is not login send him to login.php
	not_login($_SESSION['admin_id'], "login.php");

	//check that the order type is in the $_GET
	
?>
<div class="container padding-10">
	<div id="search-container">
	
		
		<?php
			// fetch all the new orders
        $orders = $db->FetchAll1("*","orders","id='ASC'");
        // show if their is no orders
        if (empty($orders)) {
        	echo "<h3 class='text-center text-upper'>No Orders</h3>";
        	exit();
        }
        // show if their is orders
        foreach ($orders as $key => $order) {
          echo "<div class='order-container'><div class='table-responsive'>"; //product order container
          echo "<table class='table table-condensed'>"; //table
          echo "
              <th>Id</th>
              <th>Customer Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>wish</th>
              <th>Address</th><tr>";

          $address = $order['address'];
          // $address = $order['address']. " ".$order['city']. " ".$order['pincode'];
          
          
          echo "<td>{$order['id']}</td>
                <td>{$order['cName']}</td>
                <td>{$order['email']}</td>
                <td>{$order['contact']}</td>
                <td>{$order['wish']}</td>
                <td>{$address}</td>
              ";



          echo "</table>";
          /*fetch the product stack and remove the */
          
          
          echo "
          </div></div>"; //close poduct order container
        }
		?>
	</div>
	<?php require_once("../inc/footer-nav.php"); ?>
</div>
<?php require_once("inc/footer.php"); ?>
