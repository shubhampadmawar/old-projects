<?php
$cName = "";
$wish = "";
$contact = "";
$email = "";
$address = "";
$sessionId = "";

if (isset($_POST['contact'])) {
$cname =$_POST['cName'];
$wish =$_POST['wish'];
$cont =$_POST['contact'];
$mail =$_POST['email'];
$add =$_POST['address'];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://2factor.in/API/V1/a7bbdff4-b972-11e7-94da-0200cd936042/SMS/".$cont."/AUTOGEN",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
  header('Location: order.php');
} else {
$json = json_decode($response, true);
  if ($json['Status'] == "Success") {
      $sessionId = $json['Details'];
      
?>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
		$("#myModal").modal('show');
	});
</script>
<div id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Please Enter OTP</h4>
            </div>
            <div class="modal-body">
				<p></p>
                <form autocomplete="off" action="order2.php" method="post">
                    <div class="form-group">
                        <input type="hidden" class="form-control" name="cName" value="<?php echo $cname; ?>" />
                        <input type="hidden" class="form-control" name="wish" value="<?php echo $wish; ?>" />
                        <input type="hidden" class="form-control" name="contact" value="<?php echo $cont; ?>" />
                        <input type="hidden" class="form-control" name="email" value="<?php echo $mail; ?>" />
                        <input type="hidden" class="form-control" name="address" value="<?php echo $add; ?>" />
                        <input type="hidden" class="form-control" name="sessionId" value="<?php echo $sessionId; ?>" />
                        <input type="text" class="form-control" name="otp" placeholder="Enter OTP" required />
                    </div> 
                    <div class="form-group" style="text-align:center;">
                        <input style="border-color: #FEAF0C;background-color: #FEAF0C;" type="submit" value="Submit" class="btn btn-primary">
                    </div>
                </form> 
            </div>
        </div>
    </div>
</div>
   
<?php 
  }
}
}else{
    header('Location: order.php');
}
?>