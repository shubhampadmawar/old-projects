<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");

	/*check product id*/
	if (isset($_GET['id'])) {
		$product_id = escape($_GET['id']);

		/*fetch product details*/
		$product = $db->Fetch("*","product","id='$product_id'");
		
		if (!$product) {
			redirect("404.php");
		}
	}else{
		redirect("404.php");
	}
?>


<?php

if ($product_id==78) {
?>

<div class="container">
	<div class="row">
		<div class="col-sm-4 padding-10 box-sizing">
			<div class="product-img-area">
				<img src="images/g.png">
			</div>
		</div>
		<div class="col-sm-8 padding-10 box-sizing">
			<div class="product-desc-container col-sm-12 padding-10 box-sizing">
				<h1 class="text-upper text-25 text-bs-primary"><?php echo $product['name']; ?></h1>
				<p class="text-20">Price <span class="text-bs-primary text-bold">Rs <?php echo $product['sp']; ?></span></p>
				<p>
				<form action="#" method="post">
					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose 1st Paratha</h5>
						<label><input type="radio" name="check_list1[]" value="1" id="Aloo-Paratha" checked >Aloo Paratha </label><br/>
						<label><input type="radio" name="check_list1[]" value="2" id="Gobi Paratha" >Gobi Paratha </label><br/>
						<label><input type="radio" name="check_list1[]" value="3" id="Peas Paratha" >Peas Paratha </label><br/>
						<label><input type="radio" name="check_list1[]" value="4" id="Onion Paratha" >Onion Paratha </label><br/>
					</div>

					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose 2nd Paratha</h5>
						<label><input type="radio" name="check_list2[]" value="1" id="Aloo-Paratha" checked >Aloo Paratha </label><br/>
						<label><input type="radio" name="check_list2[]" value="2" id="Gobi Paratha" >Gobi Paratha </label><br/>
						<label><input type="radio" name="check_list2[]" value="3" id="Peas Paratha" >Peas Paratha </label><br/>
						<label><input type="radio" name="check_list2[]" value="4" id="Onion Paratha" >Onion Paratha </label><br/>
					</div>

					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose Sabji</h5>
						<label><input type="radio" name="check_list3[]" value="1" id="Chole" checked >Chole</label><br/>
						<label><input type="radio" name="check_list3[]" value="2" id="Rajma" >Rajma</label><br/>
						<label><input type="radio" name="check_list3[]" value="3" id="Dal Makhani" >Dal Makhani</label><br/>
						<label><input type="radio" name="check_list3[]" value="4" id="Dal Fry" >Dal Fry</label><br/>
					</div>

					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose Raita</h5>
						<label><input type="radio" name="check_list4[]" value="1" id="Boondi" checked >Boondi</label><br/>
						<label><input type="radio" name="check_list4[]" value="2" id="Mix" >Mix</label><br/>
						<label><input type="radio" name="check_list4[]" value="3" id="Plain Crud" >Plain Crud</label><br/>
					</div><br/>
					<input type="submit" style="background:transparent; color:black; border:solid #f3952c 1px; border-radius:25px;" name="submit" value="Confirm Combo" class="btn btn-primary text-20 margin-5"/>
				</form></p>
<?php
$a; 
$b;
$c;
$d;

$string = null;


if(isset($_POST['submit'])){//to run PHP script on submit
if(!empty($_POST['check_list1']) && !empty($_POST['check_list2']) && !empty($_POST['check_list3']) && !empty($_POST['check_list4'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list1'] as $selected){

$a=$selected;
}
foreach($_POST['check_list2'] as $selected){

$b=$selected;
}
foreach($_POST['check_list3'] as $selected){

$c=$selected;
}
foreach($_POST['check_list4'] as $selected){

$d=$selected;
}
}
$string = "78.".$a.$b.$c.$d;
}
$product_id1= $string;
?>
				
				<input type="hidden" value="<?php echo $product_id1; ?>" id="p-id">
				
 <?php if(isset($product_id1)){?>
				
				<?php if(isset($_SESSION["pincode"])) { 
					?>

				<button class="btn btn-primary text-20 margin-5" id="add-to-cart">Add To Cart</button>
                 <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>

                 <?php  } else {?>
                <a href="index.php" class="btn btn-primary text-20 margin-5">Change your location</a>
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a> 
                    <p style="color:red">Sorry, We are yet to serve at your location.</p>
                 <?php  } ?>


                 <?php }else { ?>

                <button class="btn btn-primary text-20 margin-5"  onClick='showMessage()'>Add To Cart</button>
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>
                <?php } ?>

               
				<span id="add-to-cart-message" class="text-bold text-20"></span>
			</div>
		</div>
	</div>	
</div>
<script type="text/javascript">
			function showMessage(){
				alert("Please, Confirm your Combo");
			}
		</script>



<?php
}

elseif ($product_id==79) {
?>

<div class="container">
	<div class="row">
		<div class="col-sm-4 padding-10 box-sizing">
			<div class="product-img-area">
				<img src="images/g.png">
			</div>
		</div>
		<div class="col-sm-8 padding-10 box-sizing">
			<div class="product-desc-container col-sm-12 padding-10 box-sizing">
				<h1 class="text-upper text-25 text-bs-primary"><?php echo $product['name']; ?></h1>
					<p class="text-20">Price <span class="text-bs-primary text-bold">Rs <?php echo $product['sp']; ?></span></p>
				<p>
				<form action="#" method="post">
					<div class ="col-sm-4 padding-10 box-sizing" >
						<h5>Choose 1st Paratha</h5>
						<label><input type="radio" name="check_list11[]" value="1" id="Aloo-Paratha" checked >Cheese Onion Paratha</label><br/>
						<label><input type="radio" name="check_list11[]" value="2" id="Gobi Paratha" >Paneer Onion Paratha</label><br/>
						<label><input type="radio" name="check_list11[]" value="3" id="Peas Paratha" >Methi Corn Paratha</label><br/>
						<label><input type="radio" name="check_list11[]" value="4" id="Onion Paratha" >Gobi Chilli Cheese Paratha</label><br/>
						<label><input type="radio" name="check_list11[]" value="5" id="Onion Paratha" >Peas Paneer Paratha</label><br/>
						<label><input type="radio" name="check_list11[]" value="6" id="Onion Paratha" >Mix Paratha</label><br/>
					</div>
					<div class ="col-sm-4 padding-10 box-sizing" >
						<h5>Choose 2nd Paratha</h5>
						<label><input type="radio" name="check_list22[]" value="1" id="Aloo-Paratha" checked >Cheese Onion Paratha</label><br/>
						<label><input type="radio" name="check_list22[]" value="2" id="Gobi Paratha" >Paneer Onion Paratha</label><br/>
						<label><input type="radio" name="check_list22[]" value="3" id="Peas Paratha" >Methi Corn Paratha</label><br/>
						<label><input type="radio" name="check_list22[]" value="4" id="Onion Paratha" >Gobi Chilli Cheese Paratha</label><br/>
						<label><input type="radio" name="check_list22[]" value="5" id="Onion Paratha" >Peas Paneer Paratha</label><br/>
						<label><input type="radio" name="check_list22[]" value="6" id="Onion Paratha" >Mix Paratha</label><br/>
					</div>					
					<div class ="col-sm-4 padding-10 box-sizing" >
						<h5>Choose Raita</h5>
						<label><input type="radio" name="check_list33[]" value="1" id="Boondi" checked >Boondi</label><br/>
						<label><input type="radio" name="check_list33[]" value="2" id="Mix" >Mix</label><br/>
						<label><input type="radio" name="check_list33[]" value="3" id="Plain Crud" >Plain Crud</label><br/>
					</div><br/>
					<input type="submit" style="background:transparent; color:black; border:solid #f3952c 1px; border-radius:25px;" name="submit" value="Confirm Combo" class="btn btn-primary text-20 margin-5"/>
				</form> </br></p></br>
<?php
$e; 
$f;
$g;

$string1 = null;


if(isset($_POST['submit'])){//to run PHP script on submit
if(!empty($_POST['check_list11']) && !empty($_POST['check_list22']) && !empty($_POST['check_list33']) ){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list11'] as $selected){

$e=$selected;
}
foreach($_POST['check_list22'] as $selected){

$f=$selected;
}
foreach($_POST['check_list33'] as $selected){

$g=$selected;
}
}
$string1 = "79.".$e.$f.$g;
}
$product_id11= $string1;
?>
				
				<input type="hidden" value="<?php echo $product_id11; ?>" id="p-id">

              <?php if(isset($product_id11)){?>
				
				<?php if(isset($_SESSION["pincode"])) { 
					?>

				<button class="btn btn-primary text-20 margin-5" id="add-to-cart">Add To Cart</button>
                
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>

                 <?php  } else {?>
                <a href="index.php" class="btn btn-primary text-20 margin-5">Change your location</a>                 
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>
                    <p style="color:red">Sorry, We are yet to serve at your location.</p>
                 <?php  } ?>


                 <?php }else { ?>

                <button class="btn btn-primary text-20 margin-5"  onClick='showMessage()'>Add To Cart</button>

                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>

                <?php } ?>

				<span id="add-to-cart-message" class="text-bold text-20"></span>


			</div>
		</div>
	</div>	
</div>
<script type="text/javascript">
			function showMessage(){
				alert("Please, Confirm your Combo");
			}
		</script>


<?php
}

elseif ($product_id==80) {
?>

<div class="container">
	<div class="row">
		<div class="col-sm-4 padding-10 box-sizing">
			<div class="product-img-area">
				<img src="images/g.png">
			</div>
		</div>
		<div class="col-sm-8 padding-10 box-sizing">
			<div class="product-desc-container col-sm-12 padding-10 box-sizing">
				<h1 class="text-upper text-25 text-bs-primary"><?php echo $product['name']; ?></h1>
				<p class="text-20">Price <span class="text-bs-primary text-bold">Rs <?php echo $product['sp']; ?></span></p>
				<p>
				<form action="#" method="post">
					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose 1st Paratha</h5>
						<label><input type="radio" name="check_list111[]" value="1" id="Aloo-Paratha" checked >Aloo Paratha </label><br/>
						<label><input type="radio" name="check_list111[]" value="2" id="Gobi Paratha" >Methi Paratha</label><br/>
						<label><input type="radio" name="check_list111[]" value="3" id="Peas Paratha" >Gobi Peas Paratha</label><br/>
						<label><input type="radio" name="check_list111[]" value="4" id="Onion Paratha" >Aloo Methi Paratha</label><br/>
						<label><input type="radio" name="check_list111[]" value="4" id="Onion Paratha" >Aloo Peas Paratha</label><br/>
					</div>
					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose Sabji</h5>
						<label><input type="radio" name="check_list222[]" value="1" id="Chole" checked >Chole</label><br/>
						<label><input type="radio" name="check_list222[]" value="2" id="Rajma" >Rajma</label><br/>
						<label><input type="radio" name="check_list222[]" value="3" id="Dal Makhani" >Dal Makhani</label><br/>
						<label><input type="radio" name="check_list222[]" value="4" id="Dal Fry" >Dal</label><br/>
						<label><input type="radio" name="check_list222[]" value="4" id="Dal Fry" >Kadi</label><br/>
					</div>
					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose 1st Raita</h5>
						<label><input type="radio" name="check_list333[]" value="1" id="Boondi" checked >Boondi</label><br/>
						<label><input type="radio" name="check_list333[]" value="2" id="Mix" >Mix</label><br/>
						<label><input type="radio" name="check_list333[]" value="3" id="Plain Crud" >Plain Crud</label><br/>
				<br/>

					</div>					
					<div class ="col-sm-3 padding-10 box-sizing" >
						<h5>Choose 2nd Raita</h5>
						<label><input type="radio" name="check_list444[]" value="1" id="Boondi" checked >Boondi</label><br/>
						<label><input type="radio" name="check_list444[]" value="2" id="Mix" >Mix</label><br/>
						<label><input type="radio" name="check_list444[]" value="3" id="Plain Crud" >Plain Crud</label><br/>
					</div><br/>
					<input type="submit" style="background:transparent; color:black; border:solid #f3952c 1px; border-radius:25px;" name="submit" value="Confirm Combo" class="btn btn-primary text-20 margin-5"/>
				<br></form><br>
			</p>
<?php
$p; 
$q;
$r;
$s;

$string2 = null;


if(isset($_POST['submit'])){//to run PHP script on submit
if(!empty($_POST['check_list111']) && !empty($_POST['check_list222']) && !empty($_POST['check_list333']) && !empty($_POST['check_list444'])){
// Loop to store and display values of individual checked checkbox.
foreach($_POST['check_list111'] as $selected){

$p=$selected;
}
foreach($_POST['check_list222'] as $selected){

$q=$selected;
}
foreach($_POST['check_list333'] as $selected){

$r=$selected;
}
foreach($_POST['check_list444'] as $selected){

$s=$selected;
}
}
$string2 = "80.".$p.$q.$r.$s;
}
$product_id111= $string2;
?></p>
				
				<input type="hidden" value="<?php echo $product_id111; ?>" id="p-id">
				
				 <?php if(isset($product_id111)){?>
				
				<?php if(isset($_SESSION["pincode"])) { 
					?>

				<button class="btn btn-primary text-20 margin-5" id="add-to-cart">Add To Cart</button>
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>

                 <?php  } else {?>
                <a href="index.php" class="btn btn-primary text-20 margin-5">Change your location</a> 
                 <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>
                    <p style="color:red">Sorry, We are yet to serve at your location.</p>
                 <?php  } ?>


                 <?php }else { ?>

                <button class="btn btn-primary text-20 margin-5"  onClick='showMessage()'>Add To Cart</button>
                <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>
                <?php } ?>


               
				<span id="add-to-cart-message" class="text-bold text-20"></span>
			</div>
		</div>
	</div>	
</div>
<script type="text/javascript">
			function showMessage(){
				alert("Please, Confirm your Combo");
			}
		</script>



<?php
}
else{
?>

<div class="container">
	<div class="row">
		<div class="col-sm-4 padding-10 box-sizing">
			<div class="product-img-area">
				<img src="images/g.png">
			</div>
		</div>
		<div class="col-sm-8 padding-10 box-sizing">
			<div class="product-desc-container">
				<h1 class="text-upper text-25 text-bs-primary"><?php echo $product['name']; ?></h1>
				<p><?php echo $product['description']; ?></p>
				
				<p class="text-20">Price <span class="text-bs-primary text-bold">Rs <?php echo $product['sp']; ?></span></p>
				<input type="hidden" value="<?php echo $product_id; ?>" id="p-id">
				
				<?php if(isset($_SESSION["pincode"])) { ?>
				<button class="btn btn-primary text-20 margin-5" id="add-to-cart">Add To Cart</button>
				<a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>


                 <?php  } else {?>
                <a href="index.php" class="btn btn-primary text-20 margin-5">Change your location</a> 
                  <a class="btn btn-primary text-20 margin-5" onclick="window.history.back();" >Back</a>
                    <p style="color:red">Sorry, We are yet to serve at your location.</p>
                 <?php  } ?>
              
				<span id="add-to-cart-message" class="text-bold text-20"></span>
			</div>
		</div>
	</div>
	
</div>

<?php
}
?>

<?php
	require_once("inc/footer.php");
?>
<?php include("footer.php") ?>
