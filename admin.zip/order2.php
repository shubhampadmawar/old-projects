<script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
<?php
$cName = "CName: ";
$wish = "Name: ";
$contact = "Contact: ";
$email = "Email: ";
$address = "Address: ";
$otp = "";

if (isset($_POST['otp'])) {
$cname =$_POST['cName'];
$wish =$_POST['wish'];
$cont =$_POST['contact'];
$mail =$_POST['email'];
$add =$_POST['address'];
$sessionId = $_POST['sessionId'];

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "http://2factor.in/API/V1/a7bbdff4-b972-11e7-94da-0200cd936042/SMS/VERIFY/".$sessionId."/".$_POST['otp'],
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_POSTFIELDS => "",
  CURLOPT_HTTPHEADER => array(
    "content-type: application/x-www-form-urlencoded"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
 
    $json = json_decode($response, true);
    //echo $json['Status']; die;
    if($json['Status'] == "Error"){
    echo "<script type='text/javascript'>alert('OTP you Entered is Wrong. Try Again');window.location.href='order.php';</script>";
    //header('Location: order.php');
    }
    else{
if (!$err) {
include("connect.php");
$query="INSERT INTO orders(cName, wish, contact, email, address) values ('$cname','$wish','$cont','$mail','$add')";
$res =mysqli_query($conn, $query);
if ($res>0) 
{
include('Way2SMS-API-master/way2sms-api.php');
      $msg="Wish for:$wish\nfrom:$cname\nemail:$mail\ncontact:$cont\naddress:$add\n";

      $sms=sendWay2SMS ( '8446363668' , 'rajesh2404' , '9112456456', $msg); 

           if($sms)
           {
 echo '<script>
    setTimeout(function() {
        swal({
            title: "Thank You!",
            text: "Your wish has been accepted!",
            type: "success"
        }, function() {
            window.location = "order.php";
        });
    }, 1000);
</script>';
}
 }
}
}
mysqli_close($conn);
?>      
          
   
	<script>
		(function(document, window, $) {
		  'use strict';

		  var Site = window.Site;
		  $(document).ready(function() {
			Site.run();
		  });
		})(document, window, jQuery);
	</script>

</body>

</html>


<?php      
    
}

}

?>


