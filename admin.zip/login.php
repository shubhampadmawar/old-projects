
	<?php
		/*check user is logged in or not*/
		session_start();
		if (isset($_SESSION['id'])) {
			header("Location:menu.php");
		}
	?>
	<?php
		require_once("inc/header.php");
		require_once("inc/navbar1.php");
	?>
	

	<link rel="stylesheet" type="text/css" href="css/style2.css">
	<div class="container">
		<div class="row">

		<!-- LOGIN CONTAINER -->
			<div class="col-sm-6 col-md-6 padding-10">
				<div class="thumbnail padding-10 box-sizing">
					<h2 class="text-bs-primary text-center text-upper" style="background:#1b2530; color:white">Login</h2>
					<!-- LOGIN FORM -->
					<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="l-form">
						<div class="form-group">
							<label class="text-bs-primary" for="l-email">Email</label>
							<input type="text" class="form-control" id="l-email" name="l-email" placeholder="Enter Your Email.">
						      <span id="error_email"></span>
						</div>
						<div class="form-group">
							<label class="text-bs-primary" for="l-password">Password</label>
							<input type="password" class="form-control" id="l-password" name="l-password" placeholder="Enter Your Password.">	
						</div>
						<input type="submit" value="Login" id="l-login" name="l-login" class="btn btn-primary">
						<span id="l-message" class="text-bold text-20 float-right"></span>
						 <a href="#" data-target="#pwdModal" data-toggle="modal">Forgot Password?</a>
					</form>
					<!-- /LOGIN FORM -->
				</div>
	<div class="omb_login">
	 	<div class="row omb_row-sm-offset-3 omb_loginOr">
				<div class="col-xs-12 col-sm-6">
					<hr class="omb_hrOr">
					<span class="omb_spanOr">OR</span>
				</div>
			</div>
			        <a href="google_login.php" class="btn btn-lg btn-block omb_btn-google">
				        
				       <button class="loginBtn loginBtn--google">
	  Login with Google
	</button>
			        </a>
		        </div>	


			</div>
			<!-- / LOGIN CONTAINER -->

			<!-- REGISTER -->
			<div class="col-sm-6 col-md-6 padding-10" style="min-height:550px;">
				<div class="thumbnail padding-10 box-sizing">
				<h2 class="text-bs-primary text-center text-upper" style="background:#1b2530; color:white">Signup</h2>
					<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" id="s-form">
						<div class="form-group">
							<label for="s-name" class="text-bs-primary">Fullname</label>
							<input type="text" class="form-control" name="s-name" id="s-name" placeholder="Enter Your Fullname.">
						</div>
						<div class="form-group">
							<label for="s-email" class="text-bs-primary">Email</label>
							<input type="email" class="form-control" name="s-email" id="s-email" placeholder="Enter Your Email.">
						      <span id="error_email1"></span>
						</div>
						<div class="form-group">
							<label for="s-phone" class="text-bs-primary">Phone No</label>
							<input type="text" class="form-control" name="s-phone" id="s-phone" onkeypress="return validate(event)" placeholder="Enter Your Phone Number.">
						</div>
						<div class="form-group">
							<label for="s-password" class="text-bs-primary">Password</label>
							<input type="password" class="form-control" name="s-password" id="s-password" placeholder="Enter Your Password.">
						</div>
						<div class="form-group">
							<label for="s-password" class="text-bs-primary">Confirm Password</label>
							<input type="password" class="form-control" name="s-password" id="confirm_password" placeholder="Enter Your Password.">
						</div>
						<div class="form-group">
							<label for="s-Address" class="text-bs-primary">Address</label>
							<input type="text" class="form-control" name="s-address" id="s-address"  placeholder="Enter Your Address.">
		        		</div>
						<input type="submit" class="btn btn-primary" value="Signup" id="s-register" name="s-register">
						<span id="s-message" class="text-bold text-20 float-right"></span>
					</form>
				</div>
			</div>
			<!-- / 	REGISTER -->
		</div>
		
	</div>
	<div id="pwdModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
	  <div class="modal-dialog">
	  <div class="modal-content">
	      <div class="modal-header">
	          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
	          <h1 class="text-center">What's My Password?</h1>
	      </div>
	      <div class="modal-body">
	          <div class="col-md-12">
	                <div class="panel panel-default">
	                    <div class="panel-body">
	                        <div class="text-center">
	                          
	                          <p>If you have forgotten your password you can get it here.</p>
	                            <div class="panel-body">
	                            	<?php if(isset($msg)) {?>
	                    <div class="<?php echo $msgclass; ?>" style="padding:5px;"><?php echo $msg; ?></div>
	                <?php } ?>
	                            	<form action="get_password.php" role="form" method="post">
	                                <fieldset>
	                                    <div class="form-group">
	                                        <input class="form-control input-lg" placeholder="E-mail Address" name="email" type="email">
	                                    </div>
	                                    <input class="btn btn-lg btn-primary btn-block" value="Send My Password" type="submit">
	                                </fieldset>
	                                </form>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	      </div>
	      <div class="modal-footer">
	          <div class="col-md-12">
	          <button class="btn" data-dismiss="modal" aria-hidden="true">Cancel</button>
			  </div>	
	      </div>
	  </div>
	  </div>
	</div>
	<!-- /CONTAINER -->
	<script type="text/javascript">
	var password = document.getElementById("s-password")
	  , confirm_password = document.getElementById("confirm_password");

	function validatePassword(){
	  if(password.value != confirm_password.value) {
	    confirm_password.setCustomValidity("Passwords Doesn't Match");
	  } else {
	    confirm_password.setCustomValidity('');
	  }
	}

	password.onchange = validatePassword;
	confirm_password.onkeyup = validatePassword;
	</script>
	<?php
		require_once("inc/footer.php");
		include("footer.php");
	?>
	<script type="text/javascript">
	//Function to allow only numbers to textbox
	function validate(key)
	{
	//getting key code of pressed key
	var keycode = (key.which) ? key.which : key.keyCode;
	var phn = document.getElementById('s-phone');
	//comparing pressed keycodes
	if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57))
	{
	return false;
	}
	else
	{
	//Condition to check textbox contains ten numbers or not
	if (phn.value.length <10)
	{
	return true;
	}
	else
	{
	return false;
	}
	}
	}
	</script>
	<script type="text/javascript">
	$("#s-email").keyup(function(){
	     var email = $("#s-email").val();
	     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	     if (!filter.test(email)) {
	       //alert('Please provide a valid email address');
	       $("#error_email1").text(email+" is not a valid email address");
	       email.focus;
	       //return false;
	    } else {
	        $("#error_email1").text("");
	    }
	 });
	$("#submit-email").click(function(){
	    var email = $("#s-email").val();
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	    if (!filter.test(email)) {
	       alert('The email address you provide is not valid');
	       $("#s-email").focus();
	       return false;
	    } else {
	        
	    }
	});
	</script>
	<script type="text/javascript">
	$("#l-email").keyup(function(){
	     var email = $("#l-email").val();
	     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	     if (!filter.test(email)) {
	       //alert('Please provide a valid email address');
	       $("#error_email").text(email+" is not a valid email address");
	       email.focus;
	       //return false;
	    } else {
	        $("#error_email").text("");
	    }
	 });
	$("#submit-email").click(function(){
	    var email = $("#l-email").val();
	    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	    if (!filter.test(email)) {
	       alert('The email address you provide is not valid');
	       $("#l-email").focus();
	       return false;
	    } else {
	        
	    }
	});
	</script>

	<script type="text/javascript">
	$(function() {

	  $('#s-name').keydown(function (e) {
	  
	    if (e.shiftKey || e.ctrlKey || e.altKey) {
	    
	      e.preventDefault();
	      
	    } else {
	    
	      var key = e.keyCode;
	      
	      if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
	      
	        e.preventDefault();
	        
	      }

	    }
	    
	  });
	  
	});
	</script>