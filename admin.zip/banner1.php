    <div id="myCarousel" class="carousel slide" data-ride="carousel" >

      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        
      </ol>

      <div class="carousel-inner">
        <div class="item active">
           <img class="first-slide" class="hk-feature-slider-img" src="images/service-banner.jpg?>" alt="First slide">
        </div>
      </div>
      
    </div>