<?php
require_once("inc/header.php");
	require_once("inc/navbar.php");
?>
<div class="contact-section-page">
		
		<div class="contact_top">
			 		<div class="container">
			 			<div class="col-md-6 contact_left wow fadeInRight" data-wow-delay="0.4s">
			 				<h4>Contact Form</h4>
			 				
							   <form id="contact-form" method="post" action="contact2.php" role="form">

                        <div class="messages"></div>

                        <div class="controls">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_name">Firstname *</label>
                                        <input id="form_name" type="text" name="name" class="form-control" placeholder="Please enter your firstname *" required="required" data-error="Firstname is required.">
                                        <span id="msg"></span>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_lastname">Lastname *</label>
                                        <input id="form_lastname" type="text" name="surname" class="form-control" placeholder="Please enter your lastname *" required="required" data-error="Lastname is required.">
                                          <span id="msg1"></span>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_email">Email *</label>
                                        <input id="form_email" type="email" name="email" class="form-control" placeholder="Please enter your email *" required="required" data-error="Valid email is required.">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="form_phone">Phone</label>
                                        <input id="txtPhn" type="tel" minlength="10" name="phone" onkeypress="return validate(event)" class="form-control" placeholder="Please enter your phone">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="form_message">Message *</label>
                                        <textarea id="form_message" name="message" class="form-control" placeholder="Message for me *" rows="4" required="required" data-error="Please,leave us a message."></textarea>
                                        <span id="msg2"></span>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <input type="submit" class="btn btn-success btn-send" value="Send message">
                                </div>
                            </div>
                           
                        </div>

                    </form>
					        </div>
					        <div class="col-md-6 company-right wow fadeInLeft" data-wow-delay="0.4s">
					        	<div class="contact-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30258.488208471685!2d73.76630659008143!3d18.56001142650538!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2becff05dd3cb%3A0xa1911297fb7fab7d!2sBaner%2C+Pune%2C+Maharashtra!5e0!3m2!1sen!2sin!4v1521106891646" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>
      
	  <div class="company-right">
					        	<div class="company_ad">
							     		<h3>Contact Info</h3>
							     		<span></span>
			      						<address>
											 <p><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@makeawishindia.in"> info@makeawishindia.in</a></p>
											<p><i class="fa fa-phone" aria-hidden="true"></i> +91-9112456456</p>
									   		<p>Baner, Pune </p>
									   		<p>Maharashtra, India-411008.</p>
									 	 	
							   			</address>
							   		</div>
									</div>	
									<div class="follow-us">
										
									</div>
			
							
							 </div>
						</div>
					</div>

	</div>
	  	<script type="text/javascript">
//Function to allow only numbers to textbox
function validate(key)
{
//getting key code of pressed key
var keycode = (key.which) ? key.which : key.keyCode;
var phn = document.getElementById('txtPhn');
//comparing pressed keycodes
if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57))
{
return false;
}
else
{
//Condition to check textbox contains ten numbers or not
if (phn.value.length <10)
{
return true;
}
else
{
return false;
}
}
}
</script>

<script type="text/javascript">
var banned = ['rajesh','shubham','ananda'];
document.getElementById('form_name').addEventListener('keyup', function(e) {
		var text = document.getElementById('form_name').value;
    for (var x=0;x<banned.length;x++) {
        if (text.search(banned[x]) !== -1) {
            //alert(banned[x]+' is not allowed!');
              $('#msg').html('Sorry ' +text+' is not allowed.');
             
        }
        var regExp = new RegExp(banned[x]);
        text = text.replace(regExp,'');
    }
    document.getElementById('form_name').value = text;
},false);
</script>

<script type="text/javascript">
var banned = ['rajesh','shubham','ananda'];
document.getElementById('form_lastname').addEventListener('keyup', function(e) {
		var text = document.getElementById('form_lastname').value;
    for (var x=0;x<banned.length;x++) {
        if (text.search(banned[x]) !== -1) {
            //alert(banned[x]+' is not allowed!');
              $('#msg1').html('Sorry ' +text+' is not allowed.');
             
        }
        var regExp = new RegExp(banned[x]);
        text = text.replace(regExp,'');
    }
    document.getElementById('form_lastname').value = text;
},false);
</script>
<script type="text/javascript">
var banned = ['rajesh','shubham','ananda'];
document.getElementById('form_message').addEventListener('keyup', function(e) {
		var text = document.getElementById('form_message').value;
    for (var x=0;x<banned.length;x++) {
        if (text.search(banned[x]) !== -1) {
            //alert(banned[x]+' is not allowed!');
              $('#msg2').html('Sorry ' +text+' is not allowed.');
             
        }
        var regExp = new RegExp(banned[x]);
        text = text.replace(regExp,'');
    }
    document.getElementById('form_message').value = text;
},false);
</script>
	  <script type="text/javascript">
						$(document).ready(function() {
							/*
							var defaults = {
					  			containerID: 'toTop', // fading element id
								containerHoverID: 'toTopHover', // fading element hover id
								scrollSpeed: 1200,
								easingType: 'linear' 
					 		};
							*/
							
							$().UItoTop({ easingType: 'easeOutQuart' });
							
						});
					</script>
				<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

<?php
include("footer.php");
?>

