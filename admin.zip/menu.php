<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");
	/*fetch all the offers*/
	$offer = $db->FetchAll("image,link","offer",null," RAND()");
?>

<!-- CATEGORY CONTAINER START -->
<div class="container padding-10">
	<h1 class="text-bs-primary text-center text-upper" style="font-weight:800;  font-size:25px;padding-top:25px; padding-bottom:25px;">Menu</h1>
	<div class="row">
	<?php
		/*fetch all the category from the database*/
		$categorys = $db->FetchAll("*","category",null,"`id` DESC");
		foreach ($categorys as $key => $category) {
			$category_name = $category['name'];
			$category_id = $category['id'];
			$category_image = $category['image'];

			?>
				<div class="col-sm-3 col-md-3">
					<a href="category.php?id=<?php echo $category_id; ?>" class="thumbnail text-center">
						<img src="<?php echo $category_image;?>" alt="$category_name">
						<p class="text-center text-bold text-20"><?php echo $category_name;?></p>
					</a>
				</div>
			<?php
		}
	?>
		
	</div>
	
</div>
<?php require_once("inc/footer.php"); ?>
<?php include("footer.php") ?>