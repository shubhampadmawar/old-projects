  <?php 
  require_once("inc/header.php");
    require_once("inc/navbar.php");
      $offer = $db->FetchAll("image,link","offer",null," RAND()");
  ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>

   
    <div id="myCarousel" class="carousel slide" data-ride="carousel" >
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>

      <!-- Wrapper for slides -->
      <div class="carousel-inner">
        <div class="item active">
           <img class="first-slide" class="hk-feature-slider-img" src="<?php echo $offer[0]['image']; ?>" alt="First slide">
        </div>

        <div class="item">
           <img class="second-slide" class="hk-feature-slider-img" src="<?php echo $offer[1]['image']; ?>" alt="Second slide">
        </div>
      
        <div class="item">
          <img class="third-slide" class="hk-feature-slider-img" src="<?php echo $offer[2]['image']; ?>" alt="Third slide">
        </div>
      </div>
    </div>
  </div>