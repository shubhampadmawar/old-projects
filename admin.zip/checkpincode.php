    <?php
    session_start();

    include("connect.php");

    $result = mysqli_query($conn,"SELECT * FROM pincodes WHERE location='" . $_POST["location"] ."'");
    $row = mysqli_fetch_array($result);
    if(is_array($row)) {
    $_SESSION["pincode"] = $row[pincode];
    $_SESSION["location"] = $row[location];
    header("location:home.php");

    }
     else
      {
    	echo "<script type='text/javascript'>alert('Sorry, we are yet to serve at your location');</script>";

    }
    ?>