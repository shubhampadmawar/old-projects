<?php 
session_start();
unset($_SESSION["pincode"]);
unset($_SESSION["location"]);
header("Location:home.php");
exit();
 ?>