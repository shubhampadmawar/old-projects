
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <meta http-equiv="refresh" content="2; url=http:makeawishindia.in/user.php">
    <link rel="icon" href="images/Genie.png">
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

    <title>Make A Wish</title>

<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<!-- Optional theme -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
  </head>

  <body>
    <div class="container">
 
  <?php

include 'src/instamojo.php';

// $api = new Instamojo\Instamojo('test_db30946d5fbfa59a19dddbd0858', 'test_bc8b593f0edfd5d6f775936e8ce','https://test.instamojo.com/api/1.1/');

$api = new Instamojo\Instamojo('1026054b6a8d9b5ede8d6cbc6c2e25ce', '59fe864a5ba5cff2e9ac2ccc2017458b','https://www.instamojo.com/api/1.1/'); //live 

$payid = $_GET["payment_request_id"]; 


try {
    $response = $api->paymentRequestStatus($payid);
    $address = $response[purpose];
    $u_name= $response['payments'][0]['buyer_name'];
    $u_email = $response['payments'][0]['buyer_email'];
    $mobile = $response['payments'][0]['buyer_phone'];
    $success=$response['payments'][0]['status'];
    


        if($success=="Credit")
            {
                    $conn =mysqli_connect("localhost","makeawishindia_admin","r~}H=8?B1PAv","makeawishindia_db");
                    $booking_time = time();
                    $sql =mysqli_query($conn,"SELECT id from user WHERE email='$u_email'");
                    $res =mysqli_fetch_array($sql);
                    if ($res > 0)
                    {
                     $user_id = $res['id'];
                    }
                          $query = mysqli_query($conn,"SELECT product_id FROM cart Where user_id='$user_id'");
                          
                          $array = array();

                          while($row = mysqli_fetch_assoc($query))
                          {                          
                            $array[] = $row['product_id']; 

                          }

                            $query1 = "INSERT INTO buy (user_id, name, email, mobile, city, address, booked_time, status, status_code, product_stack) VALUES ('$user_id','$u_name','$u_email','$mobile','Pune','$address','$booking_time','Processing','1','".implode(",",$array)."')";

                            $res1 = mysqli_query($conn,$query1);
                           

                                                if ($res1) {

                                                         include('Way2SMS-API-master/way2sms-api.php');
                            $msg="New order\nfrom:$u_name\nemail:$u_email\ncontact:$mobile\naddress:$address\n";

                            $sms=sendWay2SMS ( '8446363668' , 'rajesh2404' , '9975764251', $msg); 

                     if($sms)
           {
                                  $sql1=mysqli_query($conn,"DELETE FROM cart Where user_id='$user_id'");

                                  if ($sql1) 
                                  {
                                   echo '<script>
                                  setTimeout(function() {
                                      swal({
                                          title: "Thank You,Payment Successfull!",
                                          text: "Your Order has been placed",
                                          type: "success"
                                      }, function() {
                                          window.location = "user.php";
                                      });
                                  }, 100);
                              </script>';

                                  }    
                                }
                              }

                            }
                            else{

                               echo '<script>
                                  setTimeout(function() {
                                      swal({
                                          title: "Ohho,Payment Unsuccessfull!",
                                          text: "Keep Shopping",
                                          type: "fail"
                                      }, function() {
                                          window.location = "menu.php";
                                      });
                                  }, 100);
                              </script>';
                            }
    ?>

    <?php
}
catch (Exception $e) {
    print('Error: ' . $e->getMessage());
}
  ?> 
    </div> 
  </body>
</html>
