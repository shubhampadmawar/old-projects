
		<?php
			require_once("inc/header.php");
			require_once("inc/navbar.php");
			 
		                /*change navbar option according to user login status*/
		                //session_start();
		                /* USER IS LOGGED IN*/
		                if (isset($_SESSION['id'])) {
		                  /*fetch user information*/
		                  $user_id = escape($_SESSION['id']);
		                  $user = $db->Fetch("*","user","id='$user_id'");
		                  /*get the count of cart item*/
		                  $cart_count = $db->GetNum("cart","user_id='$user_id' AND active='y'");
		                  }
			//require_once("inc/navbar.php");

			/*
				if user is logged in then only allow the user to view the page
			*/
			if (!isset($_SESSION['id'])){
				echo "<h1 class='text-center text-upper text-bs-primary'>please login to view your cart <a class='text-black' href='login.php'>login</a></h1>";
				exit();
			}
			else{
				$user_id = $_SESSION['id'];
			} 

			/*fetch all the item from the cart in respect of the user*/
			$carts = $db->FetchAll("*","cart","user_id='$user_id' AND active='y'","`id` DESC");

			/*if cart is empty*/
			if (empty($carts)) {
				echo "<h1 class='text-center text-bs-primary text-25 text-upper'>your cart is empty <a class='text-black' href='menu.php'>Add your food</a></h1>";
				exit();
			}
		?>
		<div class="container padding-10">
			<div id="cart-container-main" style="width:80%; padding-left:20%;">
			<div class="text-center text-20 text-bold" id="cart-message"></div>
				<table class="table">
				<!--<th>Menu image</th>-->
				<th>Menu detail</th>
				<th>Price</th>			
				<th>Remove</th>
				<tr>
			<?php
				$main_subtotal = 0;
				$main_shipping_charge = 0;
				$main_shipping_charged = 0;
				// create a product_id_stack
				$product_id_stack = "";
				
				foreach ($carts as $key => $cart) {
					$cart_id = $cart['id'];
					$cart_product_id = $cart['product_id'];
					// add product_id to the product_id_stack
					$product_id_stack .= $cart_product_id.",";

					if(strlen($cart_product_id)>3){

						if ($cart_product_id>79 && $cart_product_id<80) {

							$product = $db->Fetch("*","product","id='79'");


				$b=(int)substr($cart_product_id,3,1);
	            $c=(int)substr($cart_product_id,4,1);
	            $d=(int)substr($cart_product_id,5,1);
							//Raita
							switch ($d) {
	                case 1:
	                    $raita="Boondi Raita";
	                    break;
	                case 2:
	                    $raita="Mix";
	                    break;
	                case 3:
	                    $raita="Plain Curd";
	                    break;
	                default:
	                   $raita="Plain Curd";
	                }
	            
	             //Roll 2
	            switch ($c) {
	                case 1:
	                    $roll2=" Cheese Onion Paratha ";
	                    break;
	                case 2:
	                    $roll2=" Paneer Onion Paratha ";
	                    break;
	                case 3:
	                    $roll2=" Methi Corn Paratha ";
	                    break;
	                case 4:
	                    $roll2=" Gobi Chilli Cheese Paratha ";
	                    break;
	                case 5:
	                    $roll2=" Peas Paneer Paratha ";
	                    break;
	                case 6:
	                    $roll2="Mix Paratha";
	                    break;
	                default:
	                   $roll2=" Cheese Onion Paratha ";
	                }

	            //Roll 1
	            switch ($b) {
	                case 1:
	                    $roll1=" Cheese Onion Paratha ";
	                    break;
	                case 2:
	                    $roll1=" Paneer Onion Paratha ";
	                    break;
	                case 3:
	                    $roll1=" Methi Corn Paratha ";
	                    break;
	                case 4:
	                    $roll1=" Gobi Chilli Cheese Paratha ";
	                    break;
	                case 5:
	                    $roll1=" Peas Paneer Paratha";
	                    break;
	                case 6:
	                    $roll1="Mix Paratha";
	                    break;
	                default:
	                   $roll1=" Cheese Onion Paratha ";
	                }



					/*shipping charge formating*/
					if ($product['shipping'] == 0) {
						$shipping_text = "<span class='text-bold text-green'>FREE</span>";
						$shipping_price = 0;
					}else{
						$shipping_text = "Rs ".$product['shipping'];
						$shipping_price = $product['shipping'];
					}

					$subtotal = $product['sp'] + $shipping_price;
					echo "
					
					<td>{$product['name']}
						  <br><h5>First Paratha - $roll1</h5>
	                      <br><h5>Second Paratha - $roll2</h5> 
	                      <br><h5>Raita - $raita</h5>
					</td>
					<td>Rs {$product['sp']}</td>
				
					<td><button class='remove-from-cart btn btn-primary text-18' id='{$cart_id}'><i class='fa fa-trash-o'></i></button></td>
					<tr>";
						}

						if ($cart_product_id>80 && $cart_product_id<81) {
						
						$product = $db->Fetch("*","product","id='80'");



	            $b=(int)substr($cart_product_id,3,1);
	            $c=(int)substr($cart_product_id,4,1);
	            $d=(int)substr($cart_product_id,5,1);
	            $e=(int)substr($cart_product_id,6,1);
							//Raita1
							switch ($e) {
	                case 1:
	                    $raita2="Boondi Raita";
	                    break;
	                case 2:
	                    $raita2="Mix";
	                    break;
	                case 3:
	                    $raita2="Plain Curd";
	                    break;
	                default:
	                   $raita2="Plain Curd";
	                }
	     
	            //Raita2
	            switch ($d) {
	                case 1:
	                    $raita1="Boondi Raita";
	                    break;
	                case 2:
	                    $raita1="Mix";
	                    break;
	                case 3:
	                    $raita1="Plain Curd";
	                    break;
	                default:
	                   $raita1="Plain Curd";
	                }
	            //Sabji
	            switch ($c) {
	                case 1:
	                    $sabji=" Chole ";
	                    break;
	                case 2:
	                    $sabji=" Rajma ";
	                    break;
	                case 3:
	                    $sabji=" Dal Makhani ";
	                    break;
	                case 4:
	                    $sabji=" Dal ";
	                    break;
	                case 5:
	                    $sabji=" Kadi ";
	                    break;
	                default:
	                   $sabji=" Chole ";
	                }
	             //Roll 1
	            switch ($b) {
	                case 1:
	                    $roll1=" Aloo Paratha ";
	                    break;
	                case 2:
	                    $roll1=" Methi Paratha ";
	                    break;
	                case 3:
	                    $roll1=" Gobi Peas Paratha ";
	                    break;
	                case 4:
	                    $roll1=" Aloo Methi Paratha ";
	                    break;
	                case 5:
	                    $roll1=" Aloo Peas Paratha ";
	                    break;
	                default:
	                   $roll1=" Aloo Paratha ";
	                }
					/*shipping charge formating*/
					if ($product['shipping'] == 0) {
						$shipping_text = "<span class='text-bold text-green'>FREE</span>";
						$shipping_price = 0;
					}else{
						$shipping_text = "Rs ".$product['shipping'];
						$shipping_price = $product['shipping'];
					}

					$subtotal = $product['sp'] + $shipping_price;
					echo "
					
					<td>{$product['name']}
						  <br><h5>Paratha - $roll1</h5>                  
	                      <br><h5>Sabji - $sabji</h5>
	                      <br><h5>1st Raita - $raita2</h5>
	                      <br><h5>2nd Raita - $raita1</h5>
					</td>
					<td>Rs {$product['sp']}</td>
				
					<td><button class='remove-from-cart btn btn-primary text-18' id='{$cart_id}'><i class='fa fa-trash-o'></i></button></td>
					<tr>";

	}

						if ($cart_product_id>78 && $cart_product_id<79) {
						
						$product = $db->Fetch("*","product","id='78'");



							$b=(int)substr($cart_product_id,3,1);
				            $c=(int)substr($cart_product_id,4,1);
				            $d=(int)substr($cart_product_id,5,1);
				            $e=(int)substr($cart_product_id,6,1);
							//Raita
							switch ($e) {
	                case 1:
	                    $raita="Boondi Raita";
	                    break;
	                case 2:
	                    $raita="Mix";
	                    break;
	                case 3:
	                    $raita="Plain Curd";
	                    break;
	                default:
	                   $raita="Plain Curd";
	                }
	            //Sabji
	            switch ($d) {
	                case 1:
	                    $sabji=" Chole ";
	                    break;
	                case 2:
	                    $sabji=" Rajma ";
	                    break;
	                case 3:
	                    $sabji=" Dal Makhani ";
	                    break;
	                case 4:
	                    $sabji=" Dal Fry ";
	                    break;
	                default:
	                   $sabji=" Chole ";
	                }
	             //Roll 1
	            switch ($c) {
	                case 1:
	                    $roll1=" Aloo Paratha ";
	                    break;
	                case 2:
	                    $roll1=" Gobi Paratha ";
	                    break;
	                case 3:
	                    $roll1=" Peas Paratha ";
	                    break;
	                case 4:
	                    $roll1=" Onion Paratha";
	                    break;
	                default:
	                   $roll1=" Aloo Paratha ";
	                }
	            //Roll 1
	            switch ($b) {
	                case 1:
	                    $roll2=" Aloo Paratha ";
	                    break;
	                case 2:
	                    $roll2=" Gobi Paratha ";
	                    break;
	                case 3:
	                    $roll2=" Peas Paratha ";
	                    break;
	                case 4:
	                    $roll2=" Onion Paratha";
	                    break;
	                default:
	                   $roll2=" Aloo Paratha ";
	                }

					/*shipping charge formating*/
					if ($product['shipping'] == 0) {
						$shipping_text = "<span class='text-bold text-green'>FREE</span>";
						$shipping_price = 0;
					}else{
						$shipping_text = "Rs ".$product['shipping'];
						$shipping_price = $product['shipping'];
					}

					$subtotal = $product['sp'] + $shipping_price;
					echo "
					
					<td>{$product['name']}
						  <br><h5>First Paratha - $roll1</h5>
	                      <br><h5>Second Paratha - $roll2</h5>                      
	                      <br><h5>Sabji - $sabji</h5>
	                      <br><h5>Raita - $raita</h5>
					</td>
					<td>Rs {$product['sp']}</td>
				
					<td><button class='remove-from-cart btn btn-primary text-18' id='{$cart_id}'><i class='fa fa-trash-o'></i></button></td>
					<tr>";
	}

					}else{
					$product = $db->Fetch("*","product","id='$cart_product_id'");

					/*shipping charge formating*/
					if ($product['shipping'] == 0) {
						$shipping_text = "<span class='text-bold text-green'>FREE</span>";
						$shipping_price = 0;
					}else{
						$shipping_text = "Rs ".$product['shipping'];
						$shipping_price = $product['shipping'];
					}

					$subtotal = $product['sp'] + $shipping_price;
					echo "
					
					<td>{$product['name']}</td>
					<td>Rs {$product['sp']}</td>
				
					<td><button class='remove-from-cart btn btn-primary text-18' id='{$cart_id}'><i class='fa fa-trash-o'></i></button></td>
					<tr>";
	}
					/*calculate all the shipping charge*/
					$main_shipping_charge = $main_shipping_charge + $shipping_price;
					/*calculate all the sp*/
					$main_subtotal = $main_subtotal + $product['sp'];
				
				}
			?>
				</table>
				<hr/>
				<div style="width:280px;" class="float-right">
					<div class="row">
						<input type="hidden" value="<?php echo encryption("encrypt", $product_id_stack);?>" id="product-id-stack">
						<div class="col-sm-6 text-left text-muted">Total</div>
						<div class="col-sm-6 text-right">Rs <?php echo $main_subtotal; ?></div>
						<!-- / total -->
						<?php if ($main_subtotal>=200) { ?>	
						
						<div class="col-sm-6 text-left text-20 text-muted">You Pay</div>
									
						
						<div class="col-sm-6 text-20 text-right">Rs <?php echo $main_subtotal ?></div>

						<?php } else { ?>
						
						<div class="col-sm-6 text-left text-20 text-muted">You Pay</div>
									

		                 <div class="col-sm-6 text-20 text-right">Rs <?php echo $main_shipping_charged + $main_subtotal ?></div>

		                 <?php } ?>
						<!-- / you pay -->
						<div class="col-sm-12 text-25">
							<a data-toggle="modal" data-target="#myModal" href="#" class="btn btn-primary text-upper btn-block">continue</a>
						</div>
					</div>
				</div>
				<div class="float-clear"></div>
			</div> <!-- / cart-container-main  -->
			
		</div> <!-- /container -->
		<!-- buy modal -->
		<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
			<div class="modal-dialog">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h4 class="modal-title">Place Your Order</h4>
					</div><!-- / modal-header -->
					<div class="modal-body">
						<div class="form-group">
		                    <input type="radio" name="cars" checked="checked" value="2"/>Cash on Delivery
		    
		                    <input type="radio" name="cars" value="3"/> Online Payment
		        			</div>
		        <div id="Cars2" class="desc">
		        		<form action="cart.php" method="post" id="place_order_form">
		        			<?php if (isset($_SESSION['id'])){ 
		        			
		        		include("connect.php");
		                   $query= mysqli_query($conn,"SELECT * FROM `user` WHERE `id` = '".$_SESSION['id']."' ");
		                   $arr = mysqli_fetch_array($query);
		                
		                   if($arr > 0){
		        				?>
		        		
		        				<input type="hidden" value=" <?php echo $arr['fullname']; ?>" class="form-control order_input" name="order_name" id="order_name" placeholder="Enter fullname.">
		        			
		        		
		        				<input type="hidden" value=" <?php echo $arr['email']; ?>" class="form-control order_input" name="order_email" id="order_email" placeholder="Enter your email address.">
		        			        	
		        		
		        			<div class="form-group">
		        				<label for="order_city">City</label>
		        				<input type="text" readonly="true" value="Pune" class="form-control order_input" name="order_city" id="order_city" placeholder="Enter your city.">
		        			</div>
		        				<div class="form-group">
		        				<label for="order_mobile">Mobile Number</label>
		        				<input type="text" maxlength="10" minlength="10" value="<?php echo $arr['phone']; ?>" class="form-control order_input" name="order_mobile" id="order_mobile" placeholder="Enter your 10 digit mobile number">
		        			</div>
		        			<div class="form-group">	        			
		        				<input type="hidden" maxlength="6" minlength="6" class="form-control order_input" name="order_pincode" id="order_pincode" placeholder="Enter 6 digit pincode number." value="<?php echo $_SESSION["pincode"]; ?>">
		        			</div>
		        			<div class="form-group">
		        				<label for="order_address">Address</label>
		        				<textarea class="form-control order_input" name="order_address" id="order_address" placeholder="Enter Your full address."><?php echo $arr['Address']; ?></textarea>
		        			</div>
		        			
		        			<!-- make a wish -->
		        			<label for="order_pincode">Make a wish</label>
		        			<input type="checkbox" id="checkbox12"/>
							<div id="autoUpdate1" class="autoUpdate" style="display:none;">
								<div class="form-group">
		        					
		        					<textarea class="form-control order_input" name="wish" id="wish" placeholder="Enter anything u want apart from the menu"></textarea>
		        					<p>(Note: We complete your valuable wish only at Rs.30)</p>
		        				</div>
							</div>
							<!-- end make a wish -->
	<!-- make a wish script -->
	<script type="text/javascript">
	$(document).ready(function () {
	    $('#checkbox12').change(function () {
	        if (this.checked) 
	        //  ^
	           $('#autoUpdate1').fadeIn('slow');
	        else 
	            $('#autoUpdate1').fadeOut('slow');
	    });
	});
	</script>
	<!-- end make a wish script -->


		        		
		      		<!-- / modal body -->

		      		    <div class="modal-footer">
		      			
		        	<!-- 	 <div id="Cars2" class="desc"> -->
		        		 	<button type="button" class="btn btn-default" data-dismiss="modal" style="float:left">Close</button>
		        		 	<div id="order_message" class="float-left text-20 text-bold"></div>       		
		        		  
		        				<button type="submit" class="btn btn-primary">Place Order</button>
		        	      </div>

		        	</form> 
					</div>
		        </div>


		        <?php
		        		}
		        		mysqli_close($conn);
		        		     }
		        		     ?>


	<div class="modal-body" style="padding-top:0px;">
		        			 <div id="Cars3" class="desc" style="display: none;">
		        			 	<form action="pay.php" method="post" id="place_order_form">
		        			<?php if (isset($_SESSION['id'])){ 
		        			
		        		include("connect.php");
		                   $query= mysqli_query($conn,"SELECT * FROM `user` WHERE `id` = '".$_SESSION['id']."' ");
		                   $arr = mysqli_fetch_array($query);
		                 
		                   if($arr > 0){
		        				?>
		        			
		        				<input type="hidden" value=" <?php echo $arr['fullname']; ?>" class="form-control order_input" name="order_name" id="order_name" placeholder="Enter fullname.">
		        			
		        				<input type="hidden" value=" <?php echo $arr['email']; ?>" class="form-control order_input" name="order_email" id="order_email" placeholder="Enter your email address.">
		        		       	
		        		
		        			<div class="form-group">
		        				<label for="order_city">City</label>
		        				<input type="text" readonly="true" value="Pune" class="form-control order_input" name="order_city" id="order_city" placeholder="Enter your city.">
		        			</div>
		        				<div class="form-group">
		        				<label for="order_mobile">Mobile Number</label>
		        				<input type="text" maxlength="10" minlength="10" value="<?php echo $arr['phone']; ?>" class="form-control order_input" name="order_mobile" id="order_mobile" placeholder="Enter your 10 digit mobile number" required="">
		        			</div>
		        			<div class="form-group">
		        			
		        				<input type="hidden" maxlength="6" minlength="6" class="form-control order_input" name="order_pincode" id="order_pincode" placeholder="Enter 6 digit pincode number." value="<?php echo $_SESSION["pincode"]; ?>">
		        			</div>
		        			<div class="form-group">
		        				<label for="order_address">Address</label>
		        				<textarea class="form-control order_input" name="order_address" id="order_address" placeholder="Enter Your full address." required=""><?php echo $arr['Address']; ?></textarea>
		        			</div>
		        			
		        			<label for="order_pincode">Make a wish</label>
		        			<input type="checkbox" id="checkbox1"/>
							<div id="autoUpdate" class="autoUpdate" style="display:none;">
								<div class="form-group">
		        					
		        					<textarea class="form-control order_input" name="wish" id="wish" placeholder="Enter anything u want apart from the menu"></textarea>
		        					<p>(Note: We complete your valuable wish only at Rs.30)</p>
		        				</div>
							</div>
							<!-- end make a wish -->
							
	<!-- make a wish script -->
	<script type="text/javascript">
	$(document).ready(function () {
	    $('#checkbox1').change(function () {
	        if (this.checked) 
	        //  ^
	           $('#autoUpdate').fadeIn('slow');
	        else 
	            $('#autoUpdate').fadeOut('slow');
	    });
	});
	</script>
	<!-- end make a wish script -->
		        			        			
		        		
		      		<!-- / modal body -->

		      		    <div class="modal-footer">
		      		    		<input type="hidden" name="cust_id" value="<?php echo $_SESSION['id'] ?>">
		      			<?php if ($main_subtotal>=200) { ?>	

	        			 		<input type="hidden" name="product_price" value="<?php echo $main_shipping_charge + $main_subtotal ?>">
	        			 		 <?php } else{?>
	        			 		 <input type="hidden" name="product_price" value="<?php echo $main_shipping_charged + $main_subtotal ?>">
	        			 		 <?php } ?>
		        		 	<button type="button" class="btn btn-default" data-dismiss="modal" style="float:left">Close</button>
		        		 	<div id="order_message" class="float-left text-20 text-bold"></div>       		
		        		  
		        				<button type="submit" class="btn btn-primary">Pay Online</button>
		        	      </div>

		        	</form> 
		        	</div>
		        			 	
		                      </div>
		        		

		      		</div> <!-- /modal footer -->
		      		
			<?php
		        		}
		        		mysqli_close($conn);
		        		     }
		        		     ?>

				</div> <!-- / modal content -->
			</div> <!-- / modal-dialog -->
		</div> <!-- / modal -->
		<!-- / buy modal -->



		<script type="text/javascript">

		$(document).ready(function() {
		    $("input[name$='cars']").click(function() {
		        var test = $(this).val();

		        $("div.desc").hide();
		        $("#Cars" + test).show();
		    });
		});

		</script>
		<?php
			require_once("inc/footer.php");
		?>
		<?php include("footer.php") ?>
