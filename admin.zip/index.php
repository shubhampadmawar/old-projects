		<?php
		 
		//If the HTTPS is not found to be "on"
		if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on")
		{
		    //Tell the browser to redirect to the HTTPS URL.
		    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
		    //Prevent the rest of the script from executing.
		    exit;
		}
			/*include the init.php file*/
			require_once("inc/init.php");
		?>
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<title>Make A Wish</title>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta name="keywords" content="Order food online, Food delivery near me, Food delivery, Order online, wish to proove " />
			<meta name="description" content="Online food ordering services to help you to order Deliciious food at areasonablke prices. "/>

			<link rel="icon" type="image/png" href="images/Genie.png"/>
			
			
			<link rel="stylesheet" type="text/css" href="css/main.css">
			<script src="https://code.jquery.com/jquery-2.1.1.min.js" type="text/javascript"></script>
			<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.1/css/select2.min.css" rel="stylesheet" />
		</head>

		<body>
			<script type="text/javascript">
					$(document).ready(function() {
						var country = ["Baner", "Aundh","Pashan", "Bavdhan", "Kothrud", "Paud Road","Wakad","Sanghavi","Ravet", "Pimpri Chinchwad"];
						$("#country").select2({
						  data: country
						});
					});
				</script>
				
		<style type="text/css">
		.select2-container--default .select2-selection--single {
		    background-color: transparent;    
		    color:white;
		}

		.select2-container--default .select2-selection--single .select2-selection__rendered {
		    color: #fff;
		    line-height: 28px;
		}

		</style>



			<div class="limiter">
				<div class="container-login100" style="background-image: url('images/back.jpg');">
					<div class="wrap-login100" style="background-image: url('images/login_back.jpg');">
						<form class="login100-form validate-form" action="checkpincode.php" method="post">
							<span class="login100-form-logo">
								
								<img src="images/logo.png">
							</span>

							<span class="login100-form-title p-b-34 p-t-27">
								<h1 style="font-size: 1.9rem;">Enter Your Location</h1>
							</span>

							<div style="border-bottom: 2px solid rgba(255,255,255,0.24);margin-bottom: 25px; margin-top: 25px;" data-validate = "Please enter your pincode">
								<select class="input100" type="text" name="location" id="country" style="width:100%">
								</select>
							
							</div>

							
							<div class="container-login100-form-btn">
								<button class="login100-form-btn">
									Order Now
								</button>
							</div>
							</form>
							<div class="container-login100-form-btn" style="padding:10px">
								<form action="logout1.php" method="post">
								<button class="login100-form-btn">
									Skip to see Menu
								</button>
							  </form>						
							</div>
					</div>
				</div>
			</div>		

		
		<script src="js/select2.min.js"></script>	
			
		</body>
		</html>