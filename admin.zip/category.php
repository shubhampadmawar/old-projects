	<?php 
		require_once("inc/header.php");
		require_once("inc/navbar.php");

		/*check id is available*/
		if (isset($_GET['id'])) {
			$category_id = escape($_GET['id']);
			/*check that the $category_id is valid*/

			$category_num = $db->GetNum("category","id='$category_id'");

			/*no category_id is invalid*/
			if ($category_num == 0) {
				redirect("404.php");
			}
		}else{
			redirect("404.php");
		}
	?>

	<div class="orders">
		<div class="container">
			<div class="order-top">


				<li class="item-lists">
	                <?php
					/*find cat3egory name*/
					$category = $db->Fetch("*","category","id='$category_id'");
					echo "<h4>{$category['name']}</h4>";				
					?>			
				</li> 

				<li class="item-lists"> 
				<div class="special-info grid_1 simpleCart_shelfItem"> 
						<h4>Price</h4> </li>
						<?php	

					/*fetch all the product realted to this category*/
					$products = $db->FetchAll("*","product","category_id='$category_id'","`id` DESC");

					/*check there is more then 1 product of this category*/
					$product_num = $db->GetNum("product","category_id='$category_id'");

					if ($product_num == 0) {
						echo "<h3 class='text-center'>No Items Found</h3>";
						exit();
					}

					foreach ($products as $key => $product) {
						?>


						<div class="pre-top" style="border-bottom:solid #f3952c 1px;">

							<div class="pr-left">
							
								<div class="item_add"><span class="item_price"><h6 style="font-size:20px; color:black;"><?php echo $product['name']; ?></h6></span></div>
							</div>

							<div class="pr-left" style="width: 35%;">
								<div class="item_add"><span class="item_price"><h6 style="font-size:20px; color:black;">Rs.<?php echo $product['sp']; ?></h6></span></div>
							</div>	

							<div class="pr-right" style="width: 15%;">

	                      
	                        <div class="item_add"><span class="item_price">
	                       
	                    <a href="product.php?id=<?php echo $product['id']; ?>" class="btn btn-info btn-lg"  style="background:transparent; color:black; border:solid #f3952c 1px; border-radius:25px;">Pick</a></span></div>
							</div>

								<div class="clearfix"></div>
						</div>

						<?php
					}
				?>				

				<div class="clearfix"></div>


			</div>			
		</div>
	</div>

	<?php
		require_once("inc/footer.php");
	?>
	<?php include("footer.php") ?>
