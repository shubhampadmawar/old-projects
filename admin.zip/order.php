	<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");
	?>
	<div class="order-section-page">
			<div class="ordering-form">
				<div class="container">
				<div class="order-form-head text-center wow bounceInLeft" data-wow-delay="0.4s">
							<!--<h3 style="font-family:corbel">Make Your Wish</h3>-->
							
						</div>
					<div class="col-md-6 order-form-grids" style="padding-top:1px">
						
						<div class="order-form-grid  wow fadeInLeft" data-wow-delay="0.4s">
							<h5 style="color: #f3952c;font-size: 1.5em;font-weight: 100; font-family:verdana">Is there anything apart from the menu you want for yourself.</h5>
							<h5 style="font-size: 1.4em;font-weight: 100; font-family:verdana">Just try making a wish and we would try and ensure not to disappoint you.</h5>

							<form action="opt.php" method="post" id="myform">
						<input type="text" id="text" name="cName" class="text" placeholder="Enter your name" required><br>	
                        
						<input type="text" id="text" name="wish" class="text" placeholder="Enter your wish" required><br>
						<label>(Note: You will be Charged for Rs.40)</label>
						<span id="msg"></span>
						<input type="text" maxlength="10" minlength="10" id='txtPhn' onkeypress="return validate(event)" name="contact" class="text" placeholder="Enter your mobile number" required=""><br>
						<span id="spnPhoneStatus"></span>
						<input type="email" name="email" id="email" class="text" placeholder="Enter your email address" required><br>
						 <span id="error_email"></span>
						<input type="text" name="address" class="text" placeholder="Enter your address" required><br>
						<input style="display: block; padding: 0.5em 1.5em; font-size: 16px; text-transform: uppercase;font-weight: 700;border: none;background: #000; color: #fff;margin: 1em 0 0 8em;" type="submit" value="order now">
						    </form>
						</div>
					</div>
					<div class="col-md-6 ordering-image wow bounceIn" data-wow-delay="0.4s" style="margin-top: 10em;">
						<img src="images/order.png" class="img-responsive" alt="" />
					</div>
				</div>
			</div>
	  	<script type="text/javascript">
	//Function to allow only numbers to textbox
	function validate(key)
	{
	//getting key code of pressed key
	var keycode = (key.which) ? key.which : key.keyCode;
	var phn = document.getElementById('txtPhn');
	//comparing pressed keycodes
	if (!(keycode==8 || keycode==46)&&(keycode < 48 || keycode > 57))
	{
	return false;
	}
	else
	{
	//Condition to check textbox contains ten numbers or not
	if (phn.value.length <10)
	{
	return true;
	}
	else
	{
	return false;
	}
	}
	}
	</script>
	<script type="text/javascript">
	var banned = ['murder','kill','erwer'];
	document.getElementById('text').addEventListener('keyup', function(e) {
			var text = document.getElementById('text').value;
	    for (var x=0;x<banned.length;x++) {
	        if (text.search(banned[x]) !== -1) {
	            //alert(banned[x]+' is not allowed!');
	              //$('#msg').html('Sorry ' +text+' is not allowed');
	             
	        }
	        var regExp = new RegExp(banned[x]);
	        text = text.replace(regExp,'');
	    }
	    document.getElementById('text').value = text;
	},false);
	</script>

		  <script type="text/javascript">
							$(document).ready(function() {
								/*
								var defaults = {
						  			containerID: 'toTop', // fading element id
									containerHoverID: 'toTopHover', // fading element hover id
									scrollSpeed: 1200,
									easingType: 'linear' 
						 		};
								*/
								
								$().UItoTop({ easingType: 'easeOutQuart' });
								
							});
						</script>
					<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>


	<?php
	include ("validation.php");
	include("footer.php");
	?>