    <html>
    <body>
    	<head>
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">
    	</head>
    <?PHP
    $email = $_POST['email'];
    $con = mysqli_connect("localhost","makeawishindia_admin","r~}H=8?B1PAv","makeawishindia_db");

    $query = "SELECT *from user where email= '$email'";

    $res = mysqli_query($con,$query);

    $count =mysqli_num_rows($res);

    if($count==1)
    {
    $r = mysqli_fetch_assoc($res);
    $password =  $r['password'];
    $md5password = md5($password);
    $recipient = $r['email'];

    // $recipient = 'rsingone.grafx@gmail.com';
    $sender = 'rajsingone@gmail.com';


    $subject = "Password Recovery";
    $message = "Your password for makeawish login:" .$password;
    $headers = 'From:' . $sender;

    if (mail($recipient, $subject, $message, $headers))
    {
       echo '<script>
                                    setTimeout(function() {
                                        swal({
                                            title: "Thank You!",
                                            text: "Your password has been sent!",
                                            type: "success"
                                        }, function() {
                                            window.location = "login.php";
                                        });
                                    }, 1000);
                                </script>';
    }
    else
    {
        echo '<script>
                                    setTimeout(function() {
                                        swal({
                                            title: "Sorry!",
                                            text: "Please enter correct email id",
                                            type: "error"
                                        }, function() {
                                            window.location = "login.php";
                                        });
                                    }, 1000);
                                </script>';
    }
    }
    else
    {
     echo '<script>
                                    setTimeout(function() {
                                        swal({
                                            title: "Sorry!",
                                            text: "Please enter correct email id",
                                            type: "error"
                                        }, function() {
                                            window.location = "login.php";
                                        });
                                    }, 1000);
                                </script>';   
    }
    ?>
    </body>
    </html>