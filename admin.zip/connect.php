<?php
$conn = mysqli_connect("localhost","makeawishindia_admin","r~}H=8?B1PAv","makeawishindia_db");
?>