<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");
?>
<h1 class="text-center">404 Page Not Found <a href="index.php">Go Back</a></h1>