    <?php
    	require_once("inc/header.php");
    	require_once("inc/navbar.php");
      
                     //session_start();
                    /* USER IS LOGGED IN*/
                    if (isset($_SESSION['id'])) {
                      /*fetch user information*/
                      $user_id = escape($_SESSION['id']);
                      $user = $db->Fetch("*","user","id='$user_id'");
                      /*get the count of cart item*/
                      $cart_count = $db->GetNum("cart","user_id='$user_id' AND active='y'");
                      }

    	/*$_GET['search'] is available*/
    	if (!isset($_SESSION['id'])) {
    		echo "<h1 class='text-center text-upper text-bs-primary'>Please Login <a href='login.php' class='text-black'>Login</a></h1>";
    		exit();
    	}
    	$user_id = $_SESSION['id'];
    ?>
    <div class="container padding-10">
    	<div id="search-container">
    		<?php
    			// get the count of user orders
    			$order_num = $db->GetNum("buy","user_id='$user_id'");

    			// if user has no orders
    			if ($order_num == 0) {	
    				echo "<h1 class='text-center text-upper text-bs-primary'>oops! it seems that your did not have any order yet <a href='products.php' class='text-black'>Start Shoping</a></h1>";
    				exit();
    			}

    		//fetch the orders
    			$buys = $db->FetchAll("*","buy","user_id='$user_id'","`id` DESC");



    			foreach ($buys as $key => $buy) {
    				// explode the product_stack
    				$product_id_stack = explode(",", $buy['product_stack']);
                     
                    

                    $product_id_stack2 = array_filter($product_id_stack);
                   
    				$status_progressbar = "";

    				// format status code
    				switch ($buy['status_code']) {
    					case "1":
    						$status_per = "0%";
    						$status_text = "Deliverd";
    						break;
    					case "2":
    						$status_per = "33.33%";
    						$status_text = "Deliverd";
    						break;
    					case "3":
    						$status_per = "66%";
    						$status_text = "Deliverd";
    						break;
    					case "4":
    						$status_per = "100%";
    						$status_text = "Deliverd";
    						break;
    					case "5":
    						$status_per = "100%";
    						$status_text = "Canceled";
    						$status_progressbar = "progress-bar-danger";
    						break;
    					case "6":
    						$status_per = "100%";
    						$status_text = "Returned";
    						$status_progressbar = "progress-bar-danger";
    						break;
    				}
    				?>





    				<div class="border-ccc padding-10 order-container">
    					<strong>Order Id:</strong> <?php echo $buy['id'] ?><br>
    					<strong>Placed:</strong> <?php echo time_ago($buy['booked_time']); ?>
    					
    					<hr/>
    					<table style="width:100%; border-bottom:solid black;">					
    					<th>Name</th>					
    					<th>Price</th>
    					</tr>
    				<?php
    				$total = 0;
    				foreach ($product_id_stack2 as $key => $product_id) {
    					// fetch the products details

    					if(strlen($product_id)>3){
    						$p_id= (float)$product_id;
    						if($p_id>78 && $p_id<79){
    						$p_id=$p_id*10000;
    						
    						    
    						$product = $db->Fetch("id,name,image,sp,shipping","product","id='78'");
    						/*shipping charge formating*/
    						if ($product['shipping'] == 0) {
    							$shipping_text = "<span class='text-bold text-green'>FREE</span>";
    							$shipping_price = 0;
    						}else{
    							$shipping_text = "Rs ".$product['shipping'];
    							$shipping_price = $product['shipping'];
    						}
    						$total = $total + $shipping_price;
    						$total = $total + $product['sp'];

    						 	$b=(int)substr($product_id,3,1);
    				            $c=(int)substr($product_id,4,1);
    				            $d=(int)substr($product_id,5,1);
    				            $e=(int)substr($product_id,6,1);
    						//Raita
    						switch ($e) {
                    case 1:
                        $raita="Boondi Raita";
                        break;
                    case 2:
                        $raita="Mix";
                        break;
                    case 3:
                        $raita="Plain Curd";
                        break;
                    default:
                       $raita="Plain Curd";
                    }
                //Sabji
                switch ($d) {
                    case 1:
                        $sabji=" Chole ";
                        break;
                    case 2:
                        $sabji=" Rajma ";
                        break;
                    case 3:
                        $sabji=" Dal Makhani ";
                        break;
                    case 4:
                        $sabji=" Dal Fry ";
                        break;
                    default:
                       $sabji=" Chole ";
                    }
                 //Roll 1
                switch ($c) {
                    case 1:
                        $roll1=" Aloo Paratha ";
                        break;
                    case 2:
                        $roll1=" Gobi Paratha ";
                        break;
                    case 3:
                        $roll1=" Peas Paratha ";
                        break;
                    case 4:
                        $roll1=" Onion Paratha";
                        break;
                    default:
                       $roll1=" Aloo Paratha ";
                    }
                //Roll 1
                switch ($b) {
                    case 1:
                        $roll2=" Aloo Paratha ";
                        break;
                    case 2:
                        $roll2=" Gobi Paratha ";
                        break;
                    case 3:
                        $roll2=" Peas Paratha ";
                        break;
                    case 4:
                        $roll2=" Onion Paratha";
                        break;
                    default:
                       $roll2=" Aloo Paratha ";
                    }

    					?>
    				
    					<td class="padding-10 box-sizing"><h4><?php echo "Mini Paratha Combos"; ?></h4>
    						<br><h5>First Paratha - <?php echo $roll1; ?></h5>
    						<br><h5>Second Paratha - <?php echo $roll2; ?></h5>
    						<br><h5>Raita - <?php echo $raita; ?></h5>
    						<br><h5>Sabji - <?php echo $sabji; ?></h5>

    					</td>
    					
    					<td><?php echo "Rs ".$product['sp']; ?></td>

    					<tr>
    					<?php
    				}

    				/*For Special Combo*/

    				if($p_id>80 && $p_id<81){
    						  
    						$product = $db->Fetch("id,name,image,sp,shipping","product","id='80'");
    						/*shipping charge formating*/
    						if ($product['shipping'] == 0) {
    							$shipping_text = "<span class='text-bold text-green'>FREE</span>";
    							$shipping_price = 0;
    						}else{
    							$shipping_text = "Rs ".$product['shipping'];
    							$shipping_price = $product['shipping'];
    						}
    						$total = $total + $shipping_price;
    						$total = $total + $product['sp'];

    					
                $b=(int)substr($product_id,3,1);
                $c=(int)substr($product_id,4,1);
                $d=(int)substr($product_id,5,1);
                $e=(int)substr($product_id,6,1);
                //Raita1
                switch ($e) {
                    case 1:
                        $raita2="Boondi Raita";
                        break;
                    case 2:
                        $raita2="Mix";
                        break;
                    case 3:
                        $raita2="Plain Curd";
                        break;
                    default:
                       $raita2="Plain Curd";
                    }

                //Raita2
                switch ($d) {
                    case 1:
                        $raita1="Boondi Raita";
                        break;
                    case 2:
                        $raita1="Mix";
                        break;
                    case 3:
                        $raita1="Plain Curd";
                        break;
                    default:
                       $raita1="Plain Curd";
                    }
                //Sabji
                switch ($c) {
                    case 1:
                        $sabji=" Chole ";
                        break;
                    case 2:
                        $sabji=" Rajma ";
                        break;
                    case 3:
                        $sabji=" Dal Makhani ";
                        break;
                    case 4:
                        $sabji=" Dal ";
                        break;
                    case 5:
                        $sabji=" Kadi ";
                        break;
                    default:
                       $sabji=" Chole ";
                    }
                 //Roll 1
                switch ($b) {
                    case 1:
                        $roll1=" Aloo Paratha ";
                        break;
                    case 2:
                        $roll1=" Methi Paratha ";
                        break;
                    case 3:
                        $roll1=" Gobi Peas Paratha ";
                        break;
                    case 4:
                        $roll1=" Aloo Methi Paratha ";
                        break;
                    case 5:
                        $roll1=" Aloo Peas Paratha ";
                        break;
                    default:
                       $roll1=" Aloo Paratha ";
                    }

    					?>
    			
    					<td class="padding-10 box-sizing"><h4><?php echo "Specail Paratha Combo "; ?></h4>
    						<br><h5> Paratha - <?php echo $roll1; ?></h5>						
    						<br><h5>Sabji - <?php echo $sabji; ?></h5>
    						<br><h5>1st Raita - <?php echo $raita1; ?></h5>
    						<br><h5>2nd Raita - <?php echo $raita2; ?></h5>
    					</td>
    				
    					<td><?php echo "Rs ".$product['sp']; ?></td>

    					<tr>
    					<?php
    				}


    				/*For Special Combo*/

    				if($p_id>79 && $p_id<80){
    						
    						$product = $db->Fetch("id,name,image,sp,shipping","product","id='79'");
    						/*shipping charge formating*/
    						if ($product['shipping'] == 0) {
    							$shipping_text = "<span class='text-bold text-green'>FREE</span>";
    							$shipping_price = 0;
    						}else{
    							$shipping_text = "Rs ".$product['shipping'];
    							$shipping_price = $product['shipping'];
    						}
    						$total = $total + $shipping_price;
    						$total = $total + $product['sp'];

    						$b=(int)substr($product_id,3,1);
    			            $c=(int)substr($product_id,4,1);
    			            $d=(int)substr($product_id,5,1);
    						//Raita
    						switch ($d) {
                    case 1:
                        $raita="Boondi Raita";
                        break;
                    case 2:
                        $raita="Mix";
                        break;
                    case 3:
                        $raita="Plain Curd";
                        break;
                    default:
                       $raita="Plain Curd";
                    }
                
                 //Roll 2
                switch ($c) {
                    case 1:
                        $roll2=" Cheese Onion Paratha ";
                        break;
                    case 2:
                        $roll2=" Paneer Onion Paratha ";
                        break;
                    case 3:
                        $roll2=" Methi Corn Paratha ";
                        break;
                    case 4:
                        $roll2=" Gobi Chilli Cheese Paratha ";
                        break;
                    case 5:
                        $roll2=" Peas Paneer Paratha ";
                        break;
                    case 6:
                        $roll2="Mix Paratha";
                        break;
                    default:
                       $roll2=" Cheese Onion Paratha ";
                    }

                //Roll 1
                switch ($b) {
                    case 1:
                        $roll1=" Cheese Onion Paratha ";
                        break;
                    case 2:
                        $roll1=" Paneer Onion Paratha ";
                        break;
                    case 3:
                        $roll1=" Methi Corn Paratha ";
                        break;
                    case 4:
                        $roll1=" Gobi Chilli Cheese Paratha ";
                        break;
                    case 5:
                        $roll1=" Peas Paneer Paratha";
                        break;
                    case 6:
                        $roll1="Mix Paratha";
                        break;
                    default:
                       $roll1=" Cheese Onion Paratha ";
                    }

    					?>
    		
    					<td class="padding-10 box-sizing"><h4><?php echo "Paratha Combos"; ?></h4>
    						<br><h5>1st Paratha - <?php echo $roll1; ?></h5>						
    						<br><h5>2nd Paratha - <?php echo $roll2; ?></h5>	
    						<br><h5>Raita - <?php echo $raita; ?></h5>
    					</td>
    				
    					<td><?php echo "Rs ".$product['sp']; ?></td>

    					<tr>
    					<?php
    				}


    					}

    					else{
    					$product = $db->Fetch("id,name,image,sp,shipping","product","id='$product_id'");
    						/*shipping charge formating*/
    						if ($product['shipping'] == 0) {
    							$shipping_text = "<span class='text-bold text-green'>FREE</span>";
    							$shipping_price = 0;
    						}else{
    							$shipping_text = "Rs ".$product['shipping'];
    							$shipping_price = $product['shipping'];
    						}
    						$total = $total + $shipping_price;
    						$total = $total + $product['sp'];
    					?>
    	
    					<td class="padding-10 box-sizing"><h4><?php echo $product['name']; ?></h4></td>
    			
    					<td><?php echo "Rs ".$product['sp']; ?></td>
    					<tr>
    					<?php
    				}
    				}
    				?>
    				</table>
    				<p class="text-20"><strong>Total: </strong> Rs <?php echo $total; ?></p>
    				<div class="progress" style="height:5px;">
    					<div class="progress-bar <?php echo $status_progressbar; ?>" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $status_per; ?>;"></div>
    				</div>
    				<div class="row">
    					<div class="col-sm-4 text-left">Processing</div>
    				<div class="col-sm-4 text-center">Shipped</div>
    				<div class="col-sm-4 text-right"><?php echo $status_text; ?></div>
    				</div>
    			</div>
    				<?php
    			}
    		?>
    	</div><!-- / SEARCH CONTAINER -->

    </div>


    <?php require_once("inc/footer.php"); ?>
    <?php include("footer.php") ?>