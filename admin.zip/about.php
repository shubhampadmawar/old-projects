	<?php
	require_once("inc/header.php");
	require_once("inc/navbar.php");
	?>
	<div class="order-section-page">
			<div class="ordering-form">
				<div class="container">
				<div class="order-form-head text-center wow bounceInLeft" data-wow-delay="0.4s">
							<h1 style="color: #000; font-family:Verdana; font-size: 2.6em; font-weight: 500; text-transform: uppercase;">About Us</h1>
							
						</div>
					<div class="col-md-6 order-form-grids" style="padding-top:60px">
						
						<div class="order-form-grid  wow fadeInLeft" data-wow-delay="0.4s">
							<h5 style="font-family:corbel;font-size:20px;">What you wish for when you search,
							<span style="color:black;font-size:20px;font-weight:700;">'Online food delivery service in Pune' or 'food delivery near me' ?</span></h5>
						    <h5 style="color:black;font-size:20px;font-weight:700;font-family:corbel">Just a tasty food?</h5>
						    <h5 style="color:#f3952c;font-size:20px;font-weight:700;font-family:corbel">Now wish more because your genie is here!</h5>
						    <h5 style="font-size:20px;font-weight:700;font-family:corbel">Who can blend <span style="color:black;font-size:20px;font-weight:800;font-family:corbel">Delicious Food</span> along with a <span style="color:black;font-size:20px;font-weight:800;font-family:corbel">Reasonable Price </span> and not only this, we also pick up what you wish on the way to your home along with your ordered food.</h5>
	                        <h5 style="color:black;font-size:20px;font-weight:700;font-family:corbel">So what are you waiting for?</h5>
	                        <h5 style="color:black;font-size:20px;font-weight:700;font-family:corbel">You are just <a href="menu.php">one click</a> away from your wish.</h5>
						</div>
					</div>
					<div class="col-md-6 ordering-image wow bounceIn" data-wow-delay="0.4s">
						<img src="images/order.png" class="img-responsive" alt="" />
					</div>
				</div>
			</div>	  

	<?php
	include ("validation.php");
	include("footer.php");
	?>