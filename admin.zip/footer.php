
			<script src="js/jquery2.js"></script>
			<script src="js/bootstrap.min.js"></script>

	<div class="contact-section" id="contact">
				<div class="container">
					<div class="contact-section-grids">
						<div class="col-md-3 contact-section-grid wow fadeInLeft" data-wow-delay="0.4s">
							<h4>Links</h4>
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="home.php">Home</a></li>
							</ul>
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="menu.php">Menu</a></li>
							</ul>
							
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="about.php">About</a></li>
							</ul>
						</div>
						<div class="col-md-3 contact-section-grid wow fadeInLeft" data-wow-delay="0.4s">
							<h4 style="color:transparent;">Site Links</h4>
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="login.php">Login</a></li>
							</ul>
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="login.php">Register</a></li>
							</ul>
							
							<ul>
								<li><i class="point"></i></li>
								<li class="data"><a href="cart.php">Cart</a></li>
							</ul>
						</div>
						<div class="col-md-3 contact-section-grid wow fadeInRight" data-wow-delay="0.4s">
							<h4>Follow Us On</h4>
							<ul>
								<li><i class="fb"></i></li>
								<li class="data"> <a href="https://www.facebook.com/Make-A-Wish-332188617272267/" target = "_blank">  Facebook</a></li>
							</ul>
							<ul>
								<li><i class="tw"></i></li>
								<li class="data"> <a href="#">Twitter</a></li>
							</ul>
							<ul>
								<li><i class="in"></i></li>
								<li class="data"><a href="https://www.instagram.com/make_a_wish_foods/" target = "_blank"> Instagram</a></li>
							</ul>
							
						</div>
						<div class="col-md-3 contact-section-grid nth-grid wow fadeInRight" data-wow-delay="0.4s">
							<h4>Subscribe Newsletter</h4>
							<p>To get latest updates and food deals every week</p>					

							<form name="form1" method="post" action="NLprocess.php" class="bk">
							  <fieldset>							  
							    <input name="email" type="text" size="20" class="txtbox" placeholder="   Enter your email" style="border-radius:5px; border:solid 1.5px black; height:30px; padding:5px;color: #af3926;" required="">
							    <input type="submit" name="Submit" value="Go" class="button" style="border:solid 1.5px;">							    
							  </fieldset>
							</form>

						</div>
						<div class="clearfix"></div>
					</div>
				</div>
			</div>
		</div>
		<!-- content-section-ends -->
		<!-- footer-section-starts -->
		<div class="footer">
			<div class="container">
				<p style="color:black" class="wow fadeInLeft" data-wow-delay="0.4s">&copy; 2018  All rights  Reserved | Make A Wish </p>
			</div>
		</div>
		<!-- footer-section-ends -->
		  <script type="text/javascript">
							$(document).ready(function() {
								
								
							});
						</script>
					<a href="#" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>

	</body>
	</html>