<script type="text/javascript">
$("#email").keyup(function(){
     var email = $("#email").val();
     var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
     if (!filter.test(email)) {
       //alert('Please provide a valid email address');
       $("#error_email").text(email+" is not a valid email address");
       email.focus;
       //return false;
    } else {
        $("#error_email").text("");
    }
 });
$("#submit-email").click(function(){
    var email = $("#email").val();
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    if (!filter.test(email)) {
       alert('The email address you provide is not valid');
       $("#email").focus();
       return false;
    } else {
        
    }
});
</script>
