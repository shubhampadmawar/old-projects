<?php 
require_once("inc/header.php");
require_once("inc/navbar.php");
?>
                        <!--TOP BANNERS-->
                        
    <div class="banner wow fadeInUp" data-wow-delay="0.4s" id="Home">
		    <?php include("banner.php") ?>
	</div>
  
                      <!--STEP SECTION-->
                      
	<div class="content">
		<div class="ordering-section" id="Order">
			<div class="container">
				<div class="ordering-section-head text-center wow bounceInRight" data-wow-delay="0.4s">
						<!--<h3>Ordering food was never so easy before</h3>-->
						<h1 style="font-size: 2.4em;font-weight: 500;text\-transform: uppercase;">Ordering food was never so easy before</h1>
					<div class="dotted-line">
						<h4 style="font-family:verdana;font-size:1.5em;font-weight:500;">Just 4 clicks to go </h4>
					</div>
				</div>
				<div class="ordering-section-grids">
					<a href="menu.php"><div class="col-md-3 ordering-section-grid" style="background-image: url(images/order-section-bg.png); background-repeat: no-repeat">
						<div class="ordering-section-grid-process wow fadeInRight" data-wow-delay="0.4s">
						
						</div>
					</div><a>
					<div class="col-md-3 ordering-section-grid" style="background-image: url(images/order-section-bg1.png); background-repeat: no-repeat">
						<div class="ordering-section-grid-process wow fadeInRight" data-wow-delay="0.4s">
						
						</div>
					</div>
					<div class="col-md-3 ordering-section-grid" style="background-image: url(images/order-section-bg2.png); background-repeat: no-repeat">
						<div class="ordering-section-grid-process wow fadeInRight" data-wow-delay="0.4s">
							
						</div>
					</div>
					<div class="col-md-3 ordering-section-grid" style="background-image: url(images/order-section-bg3.png); background-repeat: no-repeat">
						<div class="ordering-section-grid-process wow fadeInRight" data-wow-delay="0.4s">
							
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		
		<!--TOP CUISINES SECTION-->
		
<div class="popular-restaurents" id="Popular-Restaurants">
				<div class="container">				
					<div class="ordering-section-head text-center wow bounceInRight" data-wow-delay="0.4s">
    						<div class="dotted-line">
    							<h4 style="color:white; font-family:verdana">TOP CUISINES</h4>
    						</div>
					</div>
						<div class="top-cuisine-grids">
							<div class="top-cuisine-grid wow bounceIn" data-wow-delay="0.4s">
							    <a href="product.php?id=11"><img src="images/cuisine1.png" class="img-responsive" alt="" /> 
								</a>
						    </div>
							<div class="top-cuisine-grid wow bounceIn" data-wow-delay="0.4s">
							    <a href="product.php?id=64"><img src="images/cuisine2.png" class="img-responsive" alt="" /> 
								</a>
						    </div>
							<div class="top-cuisine-grid wow bounceIn" data-wow-delay="0.4s">
							    <a href="product.php?id=70"><img src="images/cuisine3.png" class="img-responsive" alt="" /> 
								</a>
						    </div>
							<div class="top-cuisine-grid nth-grid wow bounceIn" data-wow-delay="0.4s">
							    <a href="product.php?id=54"><img src="images/cuisine4.png" class="img-responsive" alt="" /> 
							   </a>
						    </div>
						
						    
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>

	
<style type="text/css">

.top-cuisine-grid a:hover img {
        transform: scale(1.3);
        /*box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);*/
    }

</style>

				<div class="service-section">
				    <div class="service-section-top-row">
				    	<div class="container">
				    	    
				 <?php include("banner1.php"); ?> 
				 </div>
				</div>
			
			<div class="service-section-bottom-row">
				<div class="container">
					<div class="col-md-4 service-section-bottom-grid wow bounceIn "data-wow-delay="0.2s">
						<div class="icon">
							<img src="images/icon1.png" class="img-responsive" alt="" />
						</div>
						<div class="icon-data">
							<h4>100% Service Guarantee</h4>
							
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 service-section-bottom-grid wow bounceIn "data-wow-delay="0.2s">
						<div class="icon">
							<img src="images/icon2.png" class="img-responsive" alt="" />
						</div>
						<div class="icon-data">
							<h4>Fully Secure Payment</h4>
							
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-md-4 service-section-bottom-grid wow bounceIn "data-wow-delay="0.2s">
						<div class="icon">
							<img src="images/icon3.png" class="img-responsive" alt="" />
						</div>
						<div class="icon-data">
							<h4>Fast Delivery</h4>
							
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>

		<?php
           include("footer.php");
           
		 ?>