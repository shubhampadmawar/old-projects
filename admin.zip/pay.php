<?php 
// $product_name = $_POST["product_name"];
$user_id = $_POST["cust_id"];
$price = $_POST["product_price"];
$name = $_POST["order_name"];
$phone = $_POST["order_mobile"];
$email = $_POST["order_email"];
$order_address = $_POST["order_address"];

include 'src/instamojo.php';

//  $api = new Instamojo\Instamojo('test_db30946d5fbfa59a19dddbd0858', 'test_bc8b593f0edfd5d6f775936e8ce','https://test.instamojo.com/api/1.1/');

 $api = new Instamojo\Instamojo('1026054b6a8d9b5ede8d6cbc6c2e25ce', '59fe864a5ba5cff2e9ac2ccc2017458b','https://www.instamojo.com/api/1.1/');//live
try {
    $response = $api->paymentRequestCreate(array(
        "purpose" => $order_address,
        "amount" => $price,
        "buyer_name" => $name,
        "phone" => $phone,
        "buyer_address" => $order_address,
        "send_email" => true,
        "send_sms" => true,
        "email" => $email,
        'allow_repeated_payments' => false,
        "redirect_url" => "https://makeawishindia.in/thankyou.php",
        "webhook" => "https://makeawishindia.in/menu.php"
        ));
    //print_r($response);

    $pay_ulr = $response['longurl'];
    
    //Redirect($response['longurl'],302); //Go to Payment page

    header("Location: $pay_ulr");
    exit();

}
catch (Exception $e) {

    print('Error: ' . $e->getMessage());
}     
  ?>
