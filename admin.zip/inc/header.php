
<?php
 
//If the HTTPS is not found to be "on"
if(!isset($_SERVER["HTTPS"]) || $_SERVER["HTTPS"] != "on")
{
    //Tell the browser to redirect to the HTTPS URL.
    header("Location: https://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]);
    //Prevent the rest of the script from executing.
    exit;
}
	/*include the init.php file*/
	require_once("inc/init.php");
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="shortcut icon" href="images/Genie.png" />
    <script type="text/javascript">
var $zoho=$zoho || {};$zoho.salesiq = $zoho.salesiq || 
{widgetcode:"8db24bb8705830c385dfd0082c698147268d9b271d73515c11d97523ab2381c7", values:{},ready:function(){}};
var d=document;s=d.createElement("script");s.type="text/javascript";s.id="zsiqscript";s.defer=true;
s.src="https://salesiq.zoho.com/widget";t=d.getElementsByTagName("script")[0];t.parentNode.insertBefore(s,t);d.write("<div id='zsiqwidget'></div>");
</script>
	<!-- meta data for mobile support -->
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- meta for seo (search engine optimiation) -->
    <meta name="description" content="free ecomerce script, cart script, free ecommerce scrip download,free ecommerce script in php">
    <meta name="author" content="makeawishindia.in">
    	
	<!-- <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	 -->
 	<link rel="stylesheet" type="text/css" href="css/hackerkernel.css">
	<link rel="stylesheet" type="text/css" href="css/cart.css">
</head>
<body>