<footer class="footer">
    <div class="container">
        <p class="text-center">Make A Wish<i class="fa fa-heart text-red"></i> Pune,India <br>  <a href="https://makeawishindia.in">makeawishindia.in</a></p>
    </div>
</footer>