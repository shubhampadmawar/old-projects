<?php 
?>
<!DOCTYPE html>
<html>
<head>

<title>Make A Wish</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='//fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lobster+Two:400,400italic,700,700italic' rel='stylesheet' type='text/css'>
<!--Animation-->

<script type="text/javascript" src="js/move-top.js"></script>

<script type="text/javascript">
      jQuery(document).ready(function($) {
        $(".scroll").click(function(event){   
          event.preventDefault();
          $('html,body').animate({scrollTop:$(this.hash).offset().top},1200);
        });
      });
    </script>

</head>
<body background="images/back.jpg">
    <!-- header-section-starts -->
  <div class="header">
    <div class="container">
      <div class="top-header">
        <div class="logo">
          <a href="home.php"><img src="images/logo.png" class="img-responsive" alt="" /></a>
        </div>
        <div class="queries">
          <p style="text-align:center"><i style="font-size:28px;color:red"></i></p>
          <div style="height: inherit; text-align:center; font-size:15px; font-family:verdana; width:625px; text-overflow: ellipsis; overflow: hidden; white-space:nowrap;"></div>
        </div>
        <div class="header-right">
            <div class="cart box_1">
             <p><i class="fa fa-phone" aria-hidden="true"></i> </span><label>+91-9112456456</label></p>
              <p><i class="fa fa-envelope" aria-hidden="true"></i> </span><label>info@makeawishindia.in</label></p>

              <div class="clearfix"> </div>
            </div>
          </div>
        <div class="clearfix"></div>
      </div>
    </div>
      <div class="menu-bar">
      <div class="container">
        <div class="top-menu">
          <ul>
           
            <li><a href="home.php">Home</a></li>|
            <li><a href="menu.php">Menu</a></li>|
            <li><a href="order.php">Make a Wish</a></li>|
            <li><a href="about.php">about</a></li>|
            <li><a href="contact.php">Contact</a></li>
            <div class="clearfix"></div>
          </ul>
        </div>

        <div class="login-section">
          <ul>
             <?php
                /*change navbar option according to user login status*/
              
                /* USER IS LOGGED IN*/
                if (isset($_SESSION['id'])) {
                  /*fetch user information*/
                  $user_id = escape($_SESSION['id']);
                  $user = $db->Fetch("*","user","id='$user_id'");
                  /*get the count of cart item*/
                  $cart_count = $db->GetNum("cart","user_id='$user_id' AND active='y'");
                  ?>
            <li><a href="user.php"><i class="fa fa-user"></i> <span><?php echo $user['fullname']; ?></span></a></li>|
             <li title="Logout"><a href="logout.php"><i class="fa fa-sign-out"></i></a></li>|
            <li title="Cart"><a href='cart.php'><i class="fa fa-shopping-cart"> <span class="badge" id="cart-count"><?php echo $cart_count; ?></span></i></a></li>
            <!-- <li><a href="login.php">Login</a>  </li> |
            <li><a href="register.php">Register</a> </li> |
            <li><a href="#">Help</a></li> -->
            <?php } else  if (isset($_SESSION['uid']))
            {
               $user_id = escape($_SESSION['uid']);
                  $user = $db->Fetch("*","user","id='$user_id'");
                  /*get the count of cart item*/
                  $cart_count = $db->GetNum("cart","user_id='$user_id' AND active='y'");
              ?>
              <li><a href="user.php"><i class="fa fa-user"></i> <span><?php echo $_SESSION['name'] ?></span></a></li>|
             <li title="Logout"><a href="logout.php"><i class="fa fa-sign-out"></i></a></li>|
            <li title="Cart"><a href='cart.php'><i class="fa fa-shopping-cart"> <span class="badge" id="cart-count"><?php echo $cart_count; ?></span></i></a></li>
             <?php } else  if (!isset($_SESSION['id']))
             {?>
              <li><a href="login.php">Login</a> </li>
              <?php } ?>
            <div class="clearfix"></div>
          </ul>
        </div>
        <div class="clearfix"></div>
      </div>
    </div>